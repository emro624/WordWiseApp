export interface User {
  id: string;
  email: string;
  name: string;
  preferences: UserPreferences;
}

export interface UserPreferences {
  dailyGoal: number;
  notifications: boolean;
  theme: 'light' | 'dark';
  language: string;
}

export interface WordList {
  id: string;
  name: string;
  description?: string;
  language: string;
  targetLanguage: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
  totalWords: number;
  masteredWords: number;
}

export interface Word {
  id: string;
  original: string;
  translation: string;
  pronunciation?: string;
  example?: string;
  notes?: string;
  listId: string;
  createdAt: string;
  progress: {
    status: 'new' | 'learning' | 'reviewing' | 'mastered';
    correctCount: number;
    incorrectCount: number;
    strength: number;
    lastReviewed?: string;
    nextReviewDate?: string;
  };
}

export interface Story {
  id: string;
  title: string;
  description: string;
  content: string;
  translation?: string;
  language: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  imageUrl?: string;
  audioUrl?: string;
  createdAt: string;
  updatedAt: string;
  readTime: number;
  wordCount: number;
}

export interface Reminder {
  id: string;
  title?: string;
  message: string;
  time: string;
  days: number[];
  enabled: boolean;
  type: 'daily' | 'custom' | 'smart';
  listId?: string;
  dailyGoal?: number;
  createdAt: string;
  updatedAt: string;
}

export interface QuizResult {
  id: string;
  listId: string;
  score: number;
  totalQuestions: number;
  date: string;
  timeSpent: number;
  words?: Array<{
    wordId: string;
    correct: boolean;
  }>;
  wordsReviewed: string[];
}