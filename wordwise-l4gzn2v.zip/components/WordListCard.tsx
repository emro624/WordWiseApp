import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Card } from './Card';
import { WordList } from '@/types';
import { colors } from '@/constants/colors';
import { getLanguageFlag } from '@/mocks/languages';
import { BookOpen, MoreVertical } from 'lucide-react-native';

interface WordListCardProps {
  list: WordList;
  onPress: () => void;
  onOptionsPress?: () => void;
}

export const WordListCard: React.FC<WordListCardProps> = ({
  list,
  onPress,
  onOptionsPress,
}) => {
  const progressPercentage = list.totalWords > 0 
    ? Math.round((list.masteredWords / list.totalWords) * 100) 
    : 0;
  
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.7}>
      <Card style={styles.card}>
        <View style={styles.header}>
          <View style={[styles.colorIndicator, { backgroundColor: list.color }]} />
          
          <View style={styles.titleContainer}>
            <Text style={styles.title}>{list.name}</Text>
            
            <View style={styles.languageContainer}>
              <Text style={styles.languageText}>
                {getLanguageFlag(list.language)} → {getLanguageFlag(list.targetLanguage)}
              </Text>
            </View>
          </View>
          
          {onOptionsPress && (
            <TouchableOpacity 
              style={styles.optionsButton} 
              onPress={onOptionsPress}
              hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
            >
              <MoreVertical size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          )}
        </View>
        
        <Text style={styles.description} numberOfLines={2}>
          {list.description}
        </Text>
        
        <View style={styles.footer}>
          <View style={styles.statsContainer}>
            <View style={styles.statItem}>
              <BookOpen size={16} color={colors.textSecondary} />
              <Text style={styles.statText}>{list.totalWords} words</Text>
            </View>
            
            <View style={styles.statItem}>
              <Text style={styles.statText}>
                {list.masteredWords} mastered
              </Text>
            </View>
          </View>
          
          <View style={styles.progressContainer}>
            <View 
              style={[
                styles.progressBar, 
                { width: `${progressPercentage}%` }
              ]} 
            />
          </View>
          
          <Text style={styles.progressText}>{progressPercentage}%</Text>
        </View>
      </Card>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  colorIndicator: {
    width: 12,
    height: 40,
    borderRadius: 6,
    marginRight: 12,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  languageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  languageText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  optionsButton: {
    padding: 4,
  },
  description: {
    fontSize: 14,
    color: colors.text,
    marginTop: 8,
    marginBottom: 12,
  },
  footer: {
    marginTop: 8,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  progressContainer: {
    height: 6,
    backgroundColor: '#e9ecef',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
});