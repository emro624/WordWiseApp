import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { colors } from '@/constants/colors';

interface ProgressChartProps {
  data: { date: string; count: number }[];
  title?: string;
}

export const ProgressChart: React.FC<ProgressChartProps> = ({
  data,
  title,
}) => {
  const maxValue = Math.max(...data.map(item => item.count), 10);
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { weekday: 'short' }).charAt(0);
  };
  
  return (
    <View style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      
      <View style={styles.chartContainer}>
        {data.map((item, index) => {
          const height = (item.count / maxValue) * 100;
          
          return (
            <View key={index} style={styles.barContainer}>
              <View style={styles.barLabelContainer}>
                <Text style={styles.barValue}>{item.count}</Text>
              </View>
              
              <View style={styles.barWrapper}>
                <View 
                  style={[
                    styles.bar, 
                    { 
                      height: `${height}%`,
                      backgroundColor: item.count > 0 ? colors.primary : '#e9ecef',
                    }
                  ]} 
                />
              </View>
              
              <Text style={styles.dateLabel}>{formatDate(item.date)}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 16,
    color: colors.text,
  },
  chartContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 150,
  },
  barContainer: {
    flex: 1,
    alignItems: 'center',
  },
  barLabelContainer: {
    height: 20,
  },
  barValue: {
    fontSize: 10,
    color: colors.textSecondary,
  },
  barWrapper: {
    flex: 1,
    width: 20,
    justifyContent: 'flex-end',
  },
  bar: {
    width: '100%',
    borderRadius: 4,
    minHeight: 4,
  },
  dateLabel: {
    marginTop: 8,
    fontSize: 12,
    color: colors.textSecondary,
  },
});