import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Image,
} from 'react-native';
import { Card } from './Card';
import { colors } from '@/constants/colors';
import { Story } from '@/types';
import { getLanguageFlag, getLanguageName } from '@/mocks/languages';
import { 
  BookOpen, 
  Check, 
  BookmarkCheck,
  Download,
} from 'lucide-react-native';

interface StoryCardProps {
  story: Story;
  isRead: boolean;
  isBookmarked?: boolean;
  isDownloaded?: boolean;
  onPress: () => void;
  onDownload?: () => void;
  showDownloadButton?: boolean;
}

export const StoryCard: React.FC<StoryCardProps> = ({ 
  story, 
  isRead, 
  isBookmarked = false,
  isDownloaded = false,
  onPress,
  onDownload,
  showDownloadButton = false,
}) => {
  const getLevelColor = () => {
    switch (story.level) {
      case 'beginner':
        return colors.success;
      case 'intermediate':
        return colors.warning;
      case 'advanced':
        return colors.error;
      default:
        return colors.primary;
    }
  };
  
  return (
    <TouchableOpacity 
      activeOpacity={0.8}
      onPress={onPress}
    >
      <Card style={styles.container}>
        {story.imageUrl ? (
          <Image 
            source={{ uri: story.imageUrl }} 
            style={styles.image}
            resizeMode="cover"
          />
        ) : (
          <View style={[styles.image, styles.placeholderImage]}>
            <BookOpen size={32} color={colors.textSecondary} />
          </View>
        )}
        
        <View style={styles.content}>
          <View style={styles.header}>
            <Text style={styles.title} numberOfLines={2}>
              {story.title}
            </Text>
            
            {isRead && (
              <View style={styles.readBadge}>
                <Check size={12} color="white" />
              </View>
            )}
            
            {isBookmarked && (
              <View style={[styles.bookmarkBadge, styles.readBadge]}>
                <BookmarkCheck size={12} color="white" />
              </View>
            )}
            
            {isDownloaded && (
              <View style={[styles.downloadBadge, styles.readBadge]}>
                <Download size={12} color="white" />
              </View>
            )}
          </View>
          
          <Text style={styles.description} numberOfLines={2}>
            {story.description}
          </Text>
          
          <View style={styles.footer}>
            <View style={styles.languageContainer}>
              <Text style={styles.language}>
                {getLanguageFlag(story.language)} {getLanguageName(story.language)}
              </Text>
            </View>
            
            <View 
              style={[
                styles.levelBadge, 
                { backgroundColor: getLevelColor() }
              ]}
            >
              <Text style={styles.levelText}>
                {story.level.charAt(0).toUpperCase() + story.level.slice(1)}
              </Text>
            </View>
          </View>
          
          {showDownloadButton && !isDownloaded && onDownload && (
            <TouchableOpacity 
              style={styles.downloadButton}
              onPress={(e) => {
                e.stopPropagation();
                onDownload();
              }}
            >
              <Download size={16} color={colors.primary} />
              <Text style={styles.downloadText}>Download</Text>
            </TouchableOpacity>
          )}
        </View>
      </Card>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    marginBottom: 16,
    padding: 0,
    overflow: 'hidden',
  },
  image: {
    width: 100,
    height: '100%',
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
  },
  placeholderImage: {
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    padding: 12,
    position: 'relative',
  },
  header: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    flex: 1,
    marginRight: 24,
  },
  readBadge: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.success,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookmarkBadge: {
    backgroundColor: colors.primary,
    right: 24,
  },
  downloadBadge: {
    backgroundColor: colors.primary,
    right: 48,
  },
  description: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  languageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  language: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  levelBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
  },
  levelText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  downloadButton: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    gap: 4,
  },
  downloadText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '500',
  },
});