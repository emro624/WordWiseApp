import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Card } from './Card';
import { Word } from '@/types';
import { colors } from '@/constants/colors';
import { ArrowRight, Volume2, Edit, Trash2 } from 'lucide-react-native';

interface WordCardProps {
  word: Word;
  onPress?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  showActions?: boolean;
  showProgress?: boolean;
}

export const WordCard: React.FC<WordCardProps> = ({
  word,
  onPress,
  onEdit,
  onDelete,
  showActions = true,
  showProgress = true,
}) => {
  const getProgressColor = () => {
    const { status } = word.progress;
    
    switch (status) {
      case 'mastered':
        return colors.success;
      case 'reviewing':
        return '#4dabf7'; // Light blue
      case 'learning':
        return colors.warning;
      case 'new':
      default:
        return colors.textSecondary;
    }
  };
  
  const getProgressLabel = () => {
    const { status } = word.progress;
    
    switch (status) {
      case 'mastered':
        return 'Mastered';
      case 'reviewing':
        return 'Reviewing';
      case 'learning':
        return 'Learning';
      case 'new':
      default:
        return 'New';
    }
  };
  
  return (
    <TouchableOpacity 
      onPress={onPress} 
      disabled={!onPress}
      activeOpacity={onPress ? 0.7 : 1}
    >
      <Card style={styles.card}>
        <View style={styles.header}>
          <View style={styles.wordContainer}>
            <Text style={styles.original}>{word.original}</Text>
            <ArrowRight size={16} color={colors.textSecondary} style={styles.arrow} />
            <Text style={styles.translation}>{word.translation}</Text>
          </View>
          
          {showActions && (
            <View style={styles.actions}>
              <TouchableOpacity style={styles.actionButton}>
                <Volume2 size={18} color={colors.primary} />
              </TouchableOpacity>
              
              {onEdit && (
                <TouchableOpacity style={styles.actionButton} onPress={onEdit}>
                  <Edit size={18} color={colors.primary} />
                </TouchableOpacity>
              )}
              
              {onDelete && (
                <TouchableOpacity style={styles.actionButton} onPress={onDelete}>
                  <Trash2 size={18} color={colors.error} />
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>
        
        {word.pronunciation && (
          <Text style={styles.pronunciation}>/{word.pronunciation}/</Text>
        )}
        
        {word.example && (
          <Text style={styles.example}>{word.example}</Text>
        )}
        
        {showProgress && (
          <View style={styles.footer}>
            <View style={styles.progressContainer}>
              <View 
                style={[
                  styles.progressBar, 
                  { 
                    width: `${word.progress.strength}%`,
                    backgroundColor: getProgressColor(),
                  }
                ]} 
              />
            </View>
            
            <View style={styles.statsContainer}>
              <Text style={[styles.statusLabel, { color: getProgressColor() }]}>
                {getProgressLabel()}
              </Text>
              
              <Text style={styles.strengthText}>
                {word.progress.strength}%
              </Text>
            </View>
          </View>
        )}
      </Card>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    marginBottom: 12,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  wordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    flex: 1,
  },
  original: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  arrow: {
    marginHorizontal: 8,
  },
  translation: {
    fontSize: 18,
    color: colors.text,
  },
  pronunciation: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
    fontStyle: 'italic',
  },
  example: {
    fontSize: 14,
    color: colors.text,
    marginTop: 8,
    fontStyle: 'italic',
  },
  actions: {
    flexDirection: 'row',
    marginLeft: 8,
  },
  actionButton: {
    padding: 6,
    marginLeft: 4,
  },
  footer: {
    marginTop: 12,
  },
  progressContainer: {
    height: 6,
    backgroundColor: '#e9ecef',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 3,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  statusLabel: {
    fontSize: 12,
    fontWeight: '500',
  },
  strengthText: {
    fontSize: 12,
    color: colors.textSecondary,
  },
});