import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Switch,
} from 'react-native';
import { Card } from './Card';
import { colors } from '@/constants/colors';
import { Reminder } from '@/types';
import { 
  Bell, 
  Clock, 
  Calendar, 
  Trash2, 
  Edit, 
  Brain,
  ListChecks,
} from 'lucide-react-native';

interface ReminderCardProps {
  reminder: Reminder;
  onToggle: () => void;
  onDelete: () => void;
  onEdit: () => void;
  formatTime: (time: string) => string;
  formatDays: (days: number[]) => string;
  getListName?: (listId: string | undefined) => string;
}

export const ReminderCard: React.FC<ReminderCardProps> = ({ 
  reminder, 
  onToggle, 
  onDelete,
  onEdit,
  formatTime,
  formatDays,
  getListName,
}) => {
  const getTypeIcon = () => {
    switch (reminder.type) {
      case 'smart':
        return <Brain size={20} color={colors.primary} />;
      case 'custom':
        return <ListChecks size={20} color={colors.primary} />;
      default:
        return <Calendar size={20} color={colors.primary} />;
    }
  };
  
  return (
    <Card style={styles.container}>
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <View style={styles.iconContainer}>
            <Bell size={20} color={colors.primary} />
          </View>
          <Text style={styles.title}>{reminder.title || 'Reminder'}</Text>
        </View>
        
        <Switch
          value={reminder.enabled}
          onValueChange={onToggle}
          trackColor={{ false: '#e9ecef', true: colors.primary }}
          thumbColor="white"
        />
      </View>
      
      <Text style={styles.message}>{reminder.message}</Text>
      
      <View style={styles.detailsContainer}>
        <View style={styles.detailItem}>
          {getTypeIcon()}
          <Text style={styles.detailText}>
            {reminder.type === 'smart' 
              ? 'Smart Reminder' 
              : reminder.type === 'custom' 
                ? 'Custom Reminder' 
                : 'Daily Reminder'}
          </Text>
        </View>
        
        <View style={styles.detailItem}>
          <Clock size={20} color={colors.textSecondary} />
          <Text style={styles.detailText}>{formatTime(reminder.time)}</Text>
        </View>
        
        <View style={styles.detailItem}>
          <Calendar size={20} color={colors.textSecondary} />
          <Text style={styles.detailText}>{formatDays(reminder.days)}</Text>
        </View>
        
        {(reminder.type === 'custom' || reminder.type === 'smart') && getListName && (
          <View style={styles.detailItem}>
            <ListChecks size={20} color={colors.textSecondary} />
            <Text style={styles.detailText}>{getListName(reminder.listId)}</Text>
          </View>
        )}
        
        {reminder.type === 'smart' && reminder.dailyGoal && (
          <View style={styles.detailItem}>
            <Brain size={20} color={colors.textSecondary} />
            <Text style={styles.detailText}>Goal: {reminder.dailyGoal} words/day</Text>
          </View>
        )}
      </View>
      
      <View style={styles.actions}>
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={onEdit}
        >
          <Edit size={20} color={colors.primary} />
          <Text style={styles.actionText}>Edit</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={onDelete}
        >
          <Trash2 size={20} color={colors.error} />
          <Text style={[styles.actionText, styles.deleteText]}>Delete</Text>
        </TouchableOpacity>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  message: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 16,
  },
  detailsContainer: {
    marginBottom: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    color: colors.text,
    marginLeft: 8,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 16,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    gap: 4,
  },
  deleteButton: {
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
  },
  actionText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  deleteText: {
    color: colors.error,
  },
});