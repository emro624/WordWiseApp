import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator,
  StyleProp,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { colors } from '@/constants/colors';

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'text';
type ButtonSize = 'small' | 'medium' | 'large';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  style,
  textStyle,
  leftIcon,
  rightIcon,
}) => {
  // Create button style array
  const buttonStyleArray = [styles.button];
  
  // Add size-specific styles
  if (size === 'small') {
    buttonStyleArray.push(styles.buttonSmall);
  } else if (size === 'large') {
    buttonStyleArray.push(styles.buttonLarge);
  }
  
  // Add variant-specific styles
  if (variant === 'primary') {
    buttonStyleArray.push(styles.buttonPrimary);
  } else if (variant === 'secondary') {
    buttonStyleArray.push(styles.buttonSecondary);
  } else if (variant === 'outline') {
    buttonStyleArray.push(styles.buttonOutline);
  } else if (variant === 'text') {
    buttonStyleArray.push(styles.buttonText);
  }
  
  // Add disabled style if needed
  if (disabled) {
    buttonStyleArray.push(styles.buttonDisabled);
  }
  
  // Add custom style if provided
  if (style) {
    buttonStyleArray.push(style);
  }
  
  // Create text style array
  const textStyleArray = [styles.buttonTextStyle];
  
  // Add size-specific text styles
  if (size === 'small') {
    textStyleArray.push(styles.textSmall);
  } else if (size === 'large') {
    textStyleArray.push(styles.textLarge);
  }
  
  // Add variant-specific text styles
  if (variant === 'primary') {
    textStyleArray.push(styles.textPrimary);
  } else if (variant === 'secondary') {
    textStyleArray.push(styles.textSecondary);
  } else if (variant === 'outline') {
    textStyleArray.push(styles.textOutline);
  } else if (variant === 'text') {
    textStyleArray.push(styles.textText);
  }
  
  // Add disabled text style if needed
  if (disabled) {
    textStyleArray.push(styles.textDisabled);
  }
  
  // Add custom text style if provided
  if (textStyle) {
    textStyleArray.push(textStyle);
  }
  
  return (
    <TouchableOpacity
      style={buttonStyleArray}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
    >
      {leftIcon && !loading && leftIcon}
      
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variant === 'primary' ? 'white' : colors.primary} 
        />
      ) : (
        <Text style={textStyleArray}>{title}</Text>
      )}
      
      {rightIcon && !loading && rightIcon}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  buttonSmall: {
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  buttonLarge: {
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  buttonPrimary: {
    backgroundColor: colors.primary,
  },
  buttonSecondary: {
    backgroundColor: colors.secondary,
  },
  buttonOutline: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.primary,
  },
  buttonText: {
    backgroundColor: 'transparent',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  buttonTextStyle: {
    fontWeight: '600',
    fontSize: 14,
  },
  textSmall: {
    fontSize: 12,
  },
  textLarge: {
    fontSize: 16,
  },
  textPrimary: {
    color: 'white',
  },
  textSecondary: {
    color: 'white',
  },
  textOutline: {
    color: colors.primary,
  },
  textText: {
    color: colors.primary,
  },
  textDisabled: {
    opacity: 0.7,
  },
});