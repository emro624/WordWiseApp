import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Input } from '@/components/Input';
import { StoryCard } from '@/components/StoryCard';
import { EmptyState } from '@/components/EmptyState';
import { colors } from '@/constants/colors';
import { useStoryStore } from '@/store/storyStore';
import { languages } from '@/mocks/languages';
import { useWordListsStore } from '@/store/wordListsStore';
import { 
  Search, 
  BookText,
  ChevronDown,
  Filter,
  BookOpen,
  Clock,
  Download,
} from 'lucide-react-native';

export default function StoriesScreen() {
  const router = useRouter();
  const { stories, isStoryRead, isStoryBookmarked, downloadStory, isStoryDownloaded, isLoading } = useStoryStore(state => ({
    stories: state.getStories(),
    isStoryRead: state.isStoryRead,
    isStoryBookmarked: state.isStoryBookmarked,
    downloadStory: state.downloadStory,
    isStoryDownloaded: state.isStoryDownloaded,
    isLoading: state.isLoading,
  }));
  
  const wordLists = useWordListsStore(state => state.getLists());
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [showLanguageFilter, setShowLanguageFilter] = useState(false);
  const [showLevelFilter, setShowLevelFilter] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  // Get user's learning languages from word lists
  const userLanguages = Array.from(
    new Set(wordLists.map(list => list.language))
  );
  
  // Filter stories based on search, language, and level
  const filteredStories = stories.filter(story => {
    const matchesSearch = 
      !searchQuery || 
      story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesLanguage = 
      !selectedLanguage || 
      story.language === selectedLanguage;
    
    const matchesLevel = 
      !selectedLevel || 
      story.level === selectedLevel;
    
    return matchesSearch && matchesLanguage && matchesLevel;
  });
  
  // Get available languages and levels from stories
  const availableLanguages = Array.from(
    new Set(stories.map(story => story.language))
  );
  
  const availableLevels = Array.from(
    new Set(stories.map(story => story.level))
  );
  
  const handleStoryPress = (storyId: string) => {
    router.push(`/story/${storyId}`);
  };
  
  const toggleLanguageFilter = () => {
    setShowLanguageFilter(!showLanguageFilter);
    setShowLevelFilter(false);
  };
  
  const toggleLevelFilter = () => {
    setShowLevelFilter(!showLevelFilter);
    setShowLanguageFilter(false);
  };
  
  const toggleFilters = () => {
    setShowFilters(!showFilters);
    setShowLanguageFilter(false);
    setShowLevelFilter(false);
  };
  
  const selectLanguage = (languageCode: string | null) => {
    setSelectedLanguage(languageCode);
    setShowLanguageFilter(false);
  };
  
  const selectLevel = (level: string | null) => {
    setSelectedLevel(level);
    setShowLevelFilter(false);
  };
  
  const getLanguageName = (code: string) => {
    const language = languages.find(lang => lang.code === code);
    return language ? `${language.flag} ${language.name}` : code;
  };
  
  const getLevelName = (level: string) => {
    return level.charAt(0).toUpperCase() + level.slice(1);
  };
  
  const handleDownload = (storyId: string) => {
    downloadStory(storyId);
  };
  
  // Recommend stories based on user's language learning progress
  const recommendedStories = stories.filter(story => 
    userLanguages.includes(story.language) && 
    !isStoryRead(story.id)
  ).slice(0, 3);
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.title}>Stories</Text>
        
        <TouchableOpacity 
          style={styles.filterIconButton}
          onPress={toggleFilters}
        >
          <Filter size={20} color={colors.text} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.searchContainer}>
        <Input
          placeholder="Search stories..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          leftIcon={<Search size={20} color={colors.textSecondary} />}
          containerStyle={styles.searchInput}
        />
        
        {showFilters && (
          <View style={styles.filtersRow}>
            <TouchableOpacity 
              style={styles.filterButton}
              onPress={toggleLanguageFilter}
            >
              <Text style={styles.filterText}>
                {selectedLanguage 
                  ? getLanguageName(selectedLanguage) 
                  : 'Language'}
              </Text>
              <ChevronDown size={16} color={colors.text} />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.filterButton}
              onPress={toggleLevelFilter}
            >
              <Text style={styles.filterText}>
                {selectedLevel 
                  ? getLevelName(selectedLevel) 
                  : 'Level'}
              </Text>
              <ChevronDown size={16} color={colors.text} />
            </TouchableOpacity>
          </View>
        )}
        
        {showLanguageFilter && (
          <View style={styles.filterDropdown}>
            <TouchableOpacity
              style={styles.filterOption}
              onPress={() => selectLanguage(null)}
            >
              <Text style={[
                styles.filterOptionText,
                !selectedLanguage && styles.selectedFilterOption
              ]}>
                All Languages
              </Text>
            </TouchableOpacity>
            
            {availableLanguages.map(code => (
              <TouchableOpacity
                key={code}
                style={styles.filterOption}
                onPress={() => selectLanguage(code)}
              >
                <Text style={[
                  styles.filterOptionText,
                  selectedLanguage === code && styles.selectedFilterOption
                ]}>
                  {getLanguageName(code)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        
        {showLevelFilter && (
          <View style={styles.filterDropdown}>
            <TouchableOpacity
              style={styles.filterOption}
              onPress={() => selectLevel(null)}
            >
              <Text style={[
                styles.filterOptionText,
                !selectedLevel && styles.selectedFilterOption
              ]}>
                All Levels
              </Text>
            </TouchableOpacity>
            
            {availableLevels.map(level => (
              <TouchableOpacity
                key={level}
                style={styles.filterOption}
                onPress={() => selectLevel(level)}
              >
                <Text style={[
                  styles.filterOptionText,
                  selectedLevel === level && styles.selectedFilterOption
                ]}>
                  {getLevelName(level)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading stories...</Text>
        </View>
      ) : stories.length === 0 ? (
        <EmptyState
          title="No Stories Available"
          description="Check back later for language learning stories"
          icon={<BookText size={64} color={colors.textSecondary} />}
        />
      ) : (
        <>
          {recommendedStories.length > 0 && (
            <View style={styles.recommendedSection}>
              <Text style={styles.sectionTitle}>Recommended for You</Text>
              <FlatList
                data={recommendedStories}
                keyExtractor={item => `recommended-${item.id}`}
                renderItem={({ item }) => (
                  <StoryCard
                    story={item}
                    isRead={isStoryRead(item.id)}
                    isBookmarked={isStoryBookmarked(item.id)}
                    isDownloaded={isStoryDownloaded(item.id)}
                    onPress={() => handleStoryPress(item.id)}
                    onDownload={() => handleDownload(item.id)}
                    showDownloadButton
                  />
                )}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.recommendedList}
              />
            </View>
          )}
          
          <View style={styles.categoriesContainer}>
            <Text style={styles.sectionTitle}>Browse by Category</Text>
            <View style={styles.categoriesGrid}>
              <TouchableOpacity 
                style={styles.categoryCard}
                onPress={() => {
                  setSelectedLevel('beginner');
                  setShowFilters(true);
                }}
              >
                <View style={[styles.categoryIcon, { backgroundColor: 'rgba(76, 175, 80, 0.1)' }]}>
                  <BookOpen size={24} color={colors.success} />
                </View>
                <Text style={styles.categoryTitle}>Beginner</Text>
                <Text style={styles.categorySubtitle}>Easy reads</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.categoryCard}
                onPress={() => {
                  setSelectedLevel('intermediate');
                  setShowFilters(true);
                }}
              >
                <View style={[styles.categoryIcon, { backgroundColor: 'rgba(255, 152, 0, 0.1)' }]}>
                  <BookText size={24} color={colors.warning} />
                </View>
                <Text style={styles.categoryTitle}>Intermediate</Text>
                <Text style={styles.categorySubtitle}>Challenge yourself</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.categoryCard}
                onPress={() => {
                  setSelectedLevel('advanced');
                  setShowFilters(true);
                }}
              >
                <View style={[styles.categoryIcon, { backgroundColor: 'rgba(244, 67, 54, 0.1)' }]}>
                  <BookText size={24} color={colors.error} />
                </View>
                <Text style={styles.categoryTitle}>Advanced</Text>
                <Text style={styles.categorySubtitle}>Native content</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.categoryCard}
                onPress={() => router.push('/stories/downloaded')}
              >
                <View style={[styles.categoryIcon, { backgroundColor: 'rgba(93, 105, 227, 0.1)' }]}>
                  <Download size={24} color={colors.primary} />
                </View>
                <Text style={styles.categoryTitle}>Downloaded</Text>
                <Text style={styles.categorySubtitle}>Offline reading</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.allStoriesSection}>
            <Text style={styles.sectionTitle}>All Stories</Text>
            <FlatList
              data={filteredStories}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <StoryCard
                  story={item}
                  isRead={isStoryRead(item.id)}
                  isBookmarked={isStoryBookmarked(item.id)}
                  isDownloaded={isStoryDownloaded(item.id)}
                  onPress={() => handleStoryPress(item.id)}
                  onDownload={() => handleDownload(item.id)}
                  showDownloadButton
                />
              )}
              contentContainerStyle={styles.listContent}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={
                <View style={styles.noResults}>
                  <Text style={styles.noResultsText}>
                    No stories found matching your search
                  </Text>
                </View>
              }
            />
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  filterIconButton: {
    padding: 8,
  },
  searchContainer: {
    paddingHorizontal: 16,
    marginBottom: 8,
    position: 'relative',
    zIndex: 10,
  },
  searchInput: {
    marginBottom: 8,
  },
  filtersRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 8,
  },
  filterButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
  },
  filterText: {
    fontSize: 16,
    color: colors.text,
  },
  filterDropdown: {
    position: 'absolute',
    top: 96,
    left: 16,
    right: 16,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    zIndex: 20,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  filterOption: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  filterOptionText: {
    fontSize: 16,
    color: colors.text,
  },
  selectedFilterOption: {
    color: colors.primary,
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  recommendedSection: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  recommendedList: {
    paddingRight: 16,
  },
  categoriesContainer: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  categoryCard: {
    width: '48%',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  categoryIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  categorySubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  allStoriesSection: {
    flex: 1,
    paddingHorizontal: 16,
  },
  listContent: {
    paddingBottom: 16,
  },
  noResults: {
    padding: 24,
    alignItems: 'center',
  },
  noResultsText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});