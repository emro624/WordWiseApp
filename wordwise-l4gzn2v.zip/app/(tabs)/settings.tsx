import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Switch,
  Alert,
  SafeAreaView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { colors } from '@/constants/colors';
import { useUserStore } from '@/store/userStore';
import { useReminderStore } from '@/store/reminderStore';
import { 
  User, 
  Bell, 
  Moon, 
  Volume2, 
  Target, 
  ChevronRight,
  LogOut,
  Languages,
  BookOpen,
  Download,
  HelpCircle,
  Settings2,
  Shield,
} from 'lucide-react-native';

export default function SettingsScreen() {
  const router = useRouter();
  const user = useUserStore(state => state.user);
  const updatePreferences = useUserStore(state => state.updatePreferences);
  const logout = useUserStore(state => state.logout);
  
  const reminders = useReminderStore(state => state.getReminders());
  
  const [dailyGoal, setDailyGoal] = useState(user?.preferences.dailyGoal || 20);
  
  const handleToggleReminders = () => {
    if (user) {
      updatePreferences({
        reminderEnabled: !user.preferences.reminderEnabled,
      });
    }
  };
  
  const handleToggleTheme = () => {
    if (user) {
      updatePreferences({
        theme: user.preferences.theme === 'light' ? 'dark' : 'light',
      });
    }
  };
  
  const handleToggleSoundEffects = () => {
    if (user) {
      updatePreferences({
        soundEffects: !user.preferences.soundEffects,
      });
    }
  };
  
  const handleDailyGoalChange = () => {
    if (Platform.OS === 'web') {
      const goal = prompt('Set Daily Goal', dailyGoal.toString());
      if (goal !== null) {
        const newGoal = parseInt(goal, 10);
        if (!isNaN(newGoal) && newGoal > 0) {
          setDailyGoal(newGoal);
          if (user) {
            updatePreferences({ dailyGoal: newGoal });
          }
        }
      }
    } else {
      Alert.prompt(
        'Set Daily Goal',
        'How many words would you like to learn each day?',
        [
          {
            text: 'Cancel',
            style: 'cancel',
          },
          {
            text: 'Save',
            onPress: (value) => {
              const goal = parseInt(value || '20', 10);
              if (!isNaN(goal) && goal > 0) {
                setDailyGoal(goal);
                if (user) {
                  updatePreferences({ dailyGoal: goal });
                }
              }
            },
          },
        ],
        'plain-text',
        dailyGoal.toString(),
      );
    }
  };
  
  const handleLogout = () => {
    Alert.alert(
      'Log Out',
      'Are you sure you want to log out?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Log Out',
          onPress: () => {
            logout();
            router.replace('/(auth)');
          },
          style: 'destructive',
        },
      ]
    );
  };
  
  if (!user) return null;
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={styles.title}>Settings</Text>
        </View>
        
        <Card style={styles.profileCard}>
          <View style={styles.profileHeader}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {user.name.charAt(0).toUpperCase()}
              </Text>
            </View>
            
            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{user.name}</Text>
              <Text style={styles.profileEmail}>{user.email}</Text>
            </View>
          </View>
          
          <TouchableOpacity style={styles.editProfileButton}>
            <Text style={styles.editProfileText}>Edit Profile</Text>
          </TouchableOpacity>
        </Card>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Learning Preferences</Text>
          
          <Card style={styles.settingsCard}>
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={handleDailyGoalChange}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Target size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Daily Goal</Text>
              </View>
              
              <View style={styles.settingRight}>
                <Text style={styles.settingValue}>{dailyGoal} words</Text>
                <ChevronRight size={16} color={colors.textSecondary} />
              </View>
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/languages')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Languages size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>My Languages</Text>
              </View>
              
              <View style={styles.settingRight}>
                <ChevronRight size={16} color={colors.textSecondary} />
              </View>
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/bookmarks')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <BookOpen size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Bookmarked Stories</Text>
              </View>
              
              <View style={styles.settingRight}>
                <ChevronRight size={16} color={colors.textSecondary} />
              </View>
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/downloads')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Download size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Offline Content</Text>
              </View>
              
              <View style={styles.settingRight}>
                <ChevronRight size={16} color={colors.textSecondary} />
              </View>
            </TouchableOpacity>
          </Card>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notifications</Text>
          
          <Card style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Bell size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Reminders</Text>
              </View>
              
              <Switch
                value={user.preferences.reminderEnabled}
                onValueChange={handleToggleReminders}
                trackColor={{ false: '#e9ecef', true: colors.primary }}
                thumbColor="white"
              />
            </View>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/reminder/create')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Bell size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Manage Reminders</Text>
              </View>
              
              <View style={styles.settingRight}>
                <Text style={styles.settingValue}>{reminders.length}</Text>
                <ChevronRight size={16} color={colors.textSecondary} />
              </View>
            </TouchableOpacity>
          </Card>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Appearance</Text>
          
          <Card style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Moon size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Dark Mode</Text>
              </View>
              
              <Switch
                value={user.preferences.theme === 'dark'}
                onValueChange={handleToggleTheme}
                trackColor={{ false: '#e9ecef', true: colors.primary }}
                thumbColor="white"
              />
            </View>
            
            <View style={styles.divider} />
            
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Volume2 size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Sound Effects</Text>
              </View>
              
              <Switch
                value={user.preferences.soundEffects}
                onValueChange={handleToggleSoundEffects}
                trackColor={{ false: '#e9ecef', true: colors.primary }}
                thumbColor="white"
              />
            </View>
          </Card>
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account & Support</Text>
          
          <Card style={styles.settingsCard}>
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/account')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <User size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Account Settings</Text>
              </View>
              
              <ChevronRight size={16} color={colors.textSecondary} />
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/privacy')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Shield size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Privacy & Security</Text>
              </View>
              <ChevronRight size={16} color={colors.textSecondary} />
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/help')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <HelpCircle size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>Help & Support</Text>
              </View>
              
              <ChevronRight size={16} color={colors.textSecondary} />
            </TouchableOpacity>
            
            <View style={styles.divider} />
            
            <TouchableOpacity 
              style={styles.settingItem}
              onPress={() => router.push('/about')}
            >
              <View style={styles.settingLeft}>
                <View style={styles.settingIcon}>
                  <Settings2 size={20} color={colors.primary} />
                </View>
                <Text style={styles.settingLabel}>About VocabVoyage</Text>
              </View>
              
              <ChevronRight size={16} color={colors.textSecondary} />
            </TouchableOpacity>
          </Card>
        </View>
        
        <Button
          title="Log Out"
          onPress={handleLogout}
          variant="outline"
          style={styles.logoutButton}
          leftIcon={<LogOut size={20} color={colors.error} />}
          textStyle={{ color: colors.error }}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  profileCard: {
    marginBottom: 24,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  avatarText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  editProfileButton: {
    alignSelf: 'flex-start',
    paddingVertical: 8,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 16,
  },
  editProfileText: {
    color: colors.primary,
    fontWeight: '500',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
    marginLeft: 4,
  },
  settingsCard: {
    padding: 0,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  settingLabel: {
    fontSize: 16,
    color: colors.text,
  },
  settingRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingValue: {
    fontSize: 14,
    color: colors.textSecondary,
    marginRight: 8,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginLeft: 48,
  },
  logoutButton: {
    marginBottom: 24,
    borderColor: colors.error,
  },
});