import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { WordListCard } from '@/components/WordListCard';
import { EmptyState } from '@/components/EmptyState';
import { Input } from '@/components/Input';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';
import { 
  Plus, 
  Search, 
  BookOpen,
  SlidersHorizontal,
} from 'lucide-react-native';

export default function ListsScreen() {
  const router = useRouter();
  const lists = useWordListsStore(state => state.getLists());
  
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredLists = lists.filter(list => 
    list.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    list.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (list.tags && list.tags.some(tag => 
      tag.toLowerCase().includes(searchQuery.toLowerCase())
    ))
  );
  
  const handleCreateList = () => {
    router.push('/list/create');
  };
  
  const handleListOptions = (listId: string) => {
    Alert.alert(
      'List Options',
      'What would you like to do?',
      [
        {
          text: 'Edit List',
          onPress: () => router.push(`/list/edit/${listId}`),
        },
        {
          text: 'Delete List',
          onPress: () => confirmDeleteList(listId),
          style: 'destructive',
        },
        {
          text: 'Cancel',
          style: 'cancel',
        },
      ]
    );
  };
  
  const confirmDeleteList = (listId: string) => {
    Alert.alert(
      'Delete List',
      'Are you sure you want to delete this list? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => {
            useWordListsStore.getState().deleteList(listId);
          },
          style: 'destructive',
        },
      ]
    );
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Text style={styles.title}>My Word Lists</Text>
        
        <TouchableOpacity 
          style={styles.addButton}
          onPress={handleCreateList}
        >
          <Plus size={24} color="white" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.searchContainer}>
        <Input
          placeholder="Search lists..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          leftIcon={<Search size={20} color={colors.textSecondary} />}
          rightIcon={<SlidersHorizontal size={20} color={colors.textSecondary} />}
          containerStyle={styles.searchInput}
        />
      </View>
      
      {lists.length === 0 ? (
        <EmptyState
          title="No Word Lists Yet"
          description="Create your first word list to start learning vocabulary"
          icon={<BookOpen size={64} color={colors.textSecondary} />}
          actionLabel="Create List"
          onAction={handleCreateList}
        />
      ) : (
        <FlatList
          data={filteredLists}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <WordListCard
              list={item}
              onPress={() => router.push(`/list/${item.id}`)}
              onOptionsPress={() => handleListOptions(item.id)}
            />
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.noResults}>
              <Text style={styles.noResultsText}>
                No lists found matching "{searchQuery}"
              </Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  searchInput: {
    marginBottom: 8,
  },
  listContent: {
    padding: 16,
  },
  noResults: {
    padding: 24,
    alignItems: 'center',
  },
  noResultsText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});