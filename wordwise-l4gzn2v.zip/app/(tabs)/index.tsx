import React, { useMemo } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { WordListCard } from '@/components/WordListCard';
import { ProgressChart } from '@/components/ProgressChart';
import { colors } from '@/constants/colors';
import { useUserStore } from '@/store/userStore';
import { useWordListsStore } from '@/store/wordListsStore';
import { 
  Plus, 
  TrendingUp, 
  Award, 
  Calendar, 
  ArrowRight,
  BookOpen,
} from 'lucide-react-native';

export default function HomeScreen() {
  const router = useRouter();
  
  // Get user data
  const user = useUserStore(state => state.user);
  
  // Get store data
  const lists = useWordListsStore(state => state.lists);
  const getOverallProgress = useWordListsStore(state => state.getOverallProgress);
  const getStreak = useWordListsStore(state => state.getStreak);
  const getRecentActivity = useWordListsStore(state => state.getRecentActivity);
  
  // Use useMemo to cache the results of these functions
  const progress = useMemo(() => getOverallProgress(), [getOverallProgress]);
  const streak = useMemo(() => getStreak(), [getStreak]);
  const recentActivity = useMemo(() => getRecentActivity(), [getRecentActivity]);
  
  // Get the most recent lists (up to 3)
  const recentLists = useMemo(() => {
    return [...lists]
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, 3);
  }, [lists]);
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Hello, {user?.name || 'User'}</Text>
            <Text style={styles.subtitle}>Ready to continue learning?</Text>
          </View>
          
          <TouchableOpacity 
            style={styles.addButton}
            onPress={() => router.push('/list/create')}
          >
            <Plus size={24} color="white" />
          </TouchableOpacity>
        </View>
        
        <View style={styles.statsContainer}>
          <Card style={styles.statCard}>
            <View style={styles.statContent}>
              <View style={styles.statIconContainer}>
                <TrendingUp size={20} color={colors.primary} />
              </View>
              <Text style={styles.statValue}>{progress.percentage}%</Text>
              <Text style={styles.statLabel}>Overall Progress</Text>
            </View>
          </Card>
          
          <Card style={styles.statCard}>
            <View style={styles.statContent}>
              <View style={styles.statIconContainer}>
                <Award size={20} color={colors.primary} />
              </View>
              <Text style={styles.statValue}>{progress.mastered}</Text>
              <Text style={styles.statLabel}>Words Mastered</Text>
            </View>
          </Card>
          
          <Card style={styles.statCard}>
            <View style={styles.statContent}>
              <View style={styles.statIconContainer}>
                <Calendar size={20} color={colors.primary} />
              </View>
              <Text style={styles.statValue}>{streak}</Text>
              <Text style={styles.statLabel}>Day Streak</Text>
            </View>
          </Card>
        </View>
        
        <Card style={styles.activityCard}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <ProgressChart data={recentActivity} />
        </Card>
        
        <View style={styles.listsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Lists</Text>
            <TouchableOpacity 
              style={styles.seeAllButton}
              onPress={() => router.push('/lists')}
            >
              <Text style={styles.seeAllText}>See All</Text>
              <ArrowRight size={16} color={colors.primary} />
            </TouchableOpacity>
          </View>
          
          {recentLists.length > 0 ? (
            recentLists.map(list => (
              <WordListCard
                key={list.id}
                list={list}
                onPress={() => router.push(`/list/${list.id}`)}
              />
            ))
          ) : (
            <Card style={styles.emptyCard}>
              <View style={styles.emptyContent}>
                <BookOpen size={40} color={colors.textSecondary} />
                <Text style={styles.emptyTitle}>No lists yet</Text>
                <Text style={styles.emptyDescription}>
                  Create your first word list to start learning
                </Text>
                <Button
                  title="Create List"
                  onPress={() => router.push('/list/create')}
                  style={styles.emptyButton}
                />
              </View>
            </Card>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 4,
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    marginHorizontal: 4,
    padding: 12,
  },
  statContent: {
    alignItems: 'center',
  },
  statIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  activityCard: {
    marginBottom: 16,
    padding: 16,
  },
  listsSection: {
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  seeAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  seeAllText: {
    fontSize: 14,
    color: colors.primary,
  },
  emptyCard: {
    padding: 24,
    alignItems: 'center',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 16,
  },
  emptyButton: {
    marginTop: 8,
  },
});