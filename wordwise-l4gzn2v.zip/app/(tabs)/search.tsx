import React, { useState, useCallback } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Input } from '@/components/Input';
import { Card } from '@/components/Card';
import { WordListCard } from '@/components/WordListCard';
import { StoryCard } from '@/components/StoryCard';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';
import { useStoryStore } from '@/store/storyStore';
import { 
  Search, 
  BookOpen,
  List,
  X,
  History,
  TrendingUp,
} from 'lucide-react-native';

type SearchCategory = 'all' | 'lists' | 'words' | 'stories';

export default function SearchScreen() {
  const router = useRouter();
  
  // Get data from store
  const lists = useWordListsStore(state => state.getLists());
  const getAllWords = useWordListsStore(state => state.getAllWords);
  const words = getAllWords();
  const stories = useStoryStore(state => state.stories);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [category, setCategory] = useState<SearchCategory>('all');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<{
    lists: typeof lists,
    words: typeof words,
    stories: typeof stories,
  }>({
    lists: [],
    words: [],
    stories: [],
  });
  
  // Memoize the search function to prevent it from being recreated on each render
  const performSearch = useCallback(() => {
    if (!searchQuery.trim()) {
      setSearchResults({
        lists: [],
        words: [],
        stories: [],
      });
      return;
    }
    
    setIsSearching(true);
    
    // Simulate search delay
    setTimeout(() => {
      const query = searchQuery.toLowerCase();
      
      // Filter lists
      const filteredLists = category === 'all' || category === 'lists'
        ? lists.filter(list => 
            list.name.toLowerCase().includes(query) ||
            (list.description && list.description.toLowerCase().includes(query)) ||
            (list.tags && list.tags.some(tag => tag.toLowerCase().includes(query)))
          )
        : [];
      
      // Filter words
      const filteredWords = category === 'all' || category === 'words'
        ? words.filter(word => 
            word.original.toLowerCase().includes(query) ||
            word.translation.toLowerCase().includes(query) ||
            (word.notes && word.notes.toLowerCase().includes(query))
          )
        : [];
      
      // Filter stories
      const filteredStories = category === 'all' || category === 'stories'
        ? stories.filter(story => 
            story.title.toLowerCase().includes(query) ||
            story.content.toLowerCase().includes(query) ||
            (story.translation && story.translation.toLowerCase().includes(query))
          )
        : [];
      
      setSearchResults({
        lists: filteredLists,
        words: filteredWords,
        stories: filteredStories,
      });
      
      setIsSearching(false);
      
      // Add to search history if not already there
      if (query && !searchHistory.includes(query)) {
        setSearchHistory(prev => [query, ...prev.slice(0, 4)]);
      }
    }, 500);
  }, [searchQuery, category, lists, words, stories, searchHistory]);
  
  // Handle search when query or category changes
  React.useEffect(() => {
    if (searchQuery.trim()) {
      performSearch();
    } else {
      setSearchResults({
        lists: [],
        words: [],
        stories: [],
      });
    }
  }, [searchQuery, category, performSearch]);
  
  const handleClearSearch = () => {
    setSearchQuery('');
  };
  
  const handleCategoryChange = (newCategory: SearchCategory) => {
    setCategory(newCategory);
  };
  
  const handleHistoryItemPress = (query: string) => {
    setSearchQuery(query);
  };
  
  const handleClearHistory = () => {
    setSearchHistory([]);
  };
  
  const renderSearchResults = () => {
    const { lists, words, stories } = searchResults;
    const hasResults = lists.length > 0 || words.length > 0 || stories.length > 0;
    
    if (isSearching) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Searching...</Text>
        </View>
      );
    }
    
    if (searchQuery && !hasResults) {
      return (
        <View style={styles.noResults}>
          <BookOpen size={64} color={colors.textSecondary} />
          <Text style={styles.noResultsTitle}>No results found</Text>
          <Text style={styles.noResultsText}>
            Try searching with different keywords or categories
          </Text>
        </View>
      );
    }
    
    if (!searchQuery) {
      return (
        <View style={styles.historyContainer}>
          <View style={styles.historyHeader}>
            <Text style={styles.historyTitle}>Recent Searches</Text>
            {searchHistory.length > 0 && (
              <TouchableOpacity onPress={handleClearHistory}>
                <Text style={styles.clearHistoryText}>Clear</Text>
              </TouchableOpacity>
            )}
          </View>
          
          {searchHistory.length > 0 ? (
            searchHistory.map((item, index) => (
              <TouchableOpacity 
                key={index}
                style={styles.historyItem}
                onPress={() => handleHistoryItemPress(item)}
              >
                <History size={20} color={colors.textSecondary} />
                <Text style={styles.historyItemText}>{item}</Text>
              </TouchableOpacity>
            ))
          ) : (
            <Text style={styles.emptyHistoryText}>
              Your search history will appear here
            </Text>
          )}
          
          <View style={styles.trendingSection}>
            <Text style={styles.trendingTitle}>Trending Searches</Text>
            <View style={styles.trendingContainer}>
              {['Spanish', 'French', 'Travel', 'Food', 'Business', 'Greetings'].map((item, index) => (
                <TouchableOpacity 
                  key={index}
                  style={styles.trendingItem}
                  onPress={() => handleHistoryItemPress(item)}
                >
                  <TrendingUp size={16} color={colors.primary} />
                  <Text style={styles.trendingItemText}>{item}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      );
    }
    
    return (
      <FlatList
        data={[1]} // Just a dummy item to render once
        keyExtractor={() => 'search-results'}
        renderItem={() => (
          <View style={styles.resultsContainer}>
            {lists.length > 0 && (
              <View style={styles.resultSection}>
                <Text style={styles.resultSectionTitle}>Word Lists ({lists.length})</Text>
                {lists.map(list => (
                  <WordListCard
                    key={list.id}
                    list={list}
                    onPress={() => router.push(`/list/${list.id}`)}
                  />
                ))}
              </View>
            )}
            
            {words.length > 0 && (
              <View style={styles.resultSection}>
                <Text style={styles.resultSectionTitle}>Words ({words.length})</Text>
                {words.map(word => (
                  <Card key={word.id} style={styles.wordCard}>
                    <View style={styles.wordCardContent}>
                      <View>
                        <Text style={styles.wordOriginal}>{word.original}</Text>
                        <Text style={styles.wordTranslation}>{word.translation}</Text>
                      </View>
                      
                      <TouchableOpacity 
                        style={styles.viewListButton}
                        onPress={() => router.push(`/list/${word.listId}`)}
                      >
                        <Text style={styles.viewListText}>View List</Text>
                      </TouchableOpacity>
                    </View>
                  </Card>
                ))}
              </View>
            )}
            
            {stories.length > 0 && (
              <View style={styles.resultSection}>
                <Text style={styles.resultSectionTitle}>Stories ({stories.length})</Text>
                {stories.map(story => (
                  <StoryCard
                    key={story.id}
                    story={story}
                    isRead={false}
                    onPress={() => router.push(`/story/${story.id}`)}
                  />
                ))}
              </View>
            )}
          </View>
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    );
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <View style={styles.header}>
        <Input
          placeholder="Search words, lists, stories..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          leftIcon={<Search size={20} color={colors.textSecondary} />}
          rightIcon={
            searchQuery ? (
              <TouchableOpacity onPress={handleClearSearch}>
                <X size={20} color={colors.textSecondary} />
              </TouchableOpacity>
            ) : null
          }
          containerStyle={styles.searchInput}
          autoFocus
        />
      </View>
      
      <View style={styles.categories}>
        <TouchableOpacity
          style={[
            styles.categoryButton,
            category === 'all' && styles.activeCategoryButton
          ]}
          onPress={() => handleCategoryChange('all')}
        >
          <Text 
            style={[
              styles.categoryText,
              category === 'all' && styles.activeCategoryText
            ]}
          >
            All
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.categoryButton,
            category === 'lists' && styles.activeCategoryButton
          ]}
          onPress={() => handleCategoryChange('lists')}
        >
          <List size={16} color={category === 'lists' ? 'white' : colors.text} />
          <Text 
            style={[
              styles.categoryText,
              category === 'lists' && styles.activeCategoryText
            ]}
          >
            Lists
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.categoryButton,
            category === 'words' && styles.activeCategoryButton
          ]}
          onPress={() => handleCategoryChange('words')}
        >
          <Text 
            style={[
              styles.categoryText,
              category === 'words' && styles.activeCategoryText
            ]}
          >
            Words
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.categoryButton,
            category === 'stories' && styles.activeCategoryButton
          ]}
          onPress={() => handleCategoryChange('stories')}
        >
          <BookOpen size={16} color={category === 'stories' ? 'white' : colors.text} />
          <Text 
            style={[
              styles.categoryText,
              category === 'stories' && styles.activeCategoryText
            ]}
          >
            Stories
          </Text>
        </TouchableOpacity>
      </View>
      
      {renderSearchResults()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
  },
  searchInput: {
    marginBottom: 0,
  },
  categories: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  categoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.border,
    gap: 4,
  },
  activeCategoryButton: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  categoryText: {
    fontSize: 14,
    color: colors.text,
  },
  activeCategoryText: {
    color: 'white',
    fontWeight: '500',
  },
  listContent: {
    padding: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  noResults: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  noResultsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  noResultsText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  historyContainer: {
    padding: 16,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  historyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  clearHistoryText: {
    fontSize: 14,
    color: colors.primary,
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    gap: 12,
  },
  historyItemText: {
    fontSize: 16,
    color: colors.text,
  },
  emptyHistoryText: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: 24,
    marginBottom: 24,
  },
  trendingSection: {
    marginTop: 24,
  },
  trendingTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  trendingContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  trendingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 16,
    gap: 6,
  },
  trendingItemText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  resultsContainer: {
    gap: 24,
  },
  resultSection: {
    gap: 8,
  },
  resultSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  wordCard: {
    marginBottom: 8,
  },
  wordCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  wordOriginal: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  wordTranslation: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  viewListButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 16,
  },
  viewListText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '500',
  },
});