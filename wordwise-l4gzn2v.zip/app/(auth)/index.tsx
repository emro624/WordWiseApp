import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  TouchableOpacity,
  Pressable
} from 'react-native';
import { Link, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '@/components/Button';
import { colors } from '@/constants/colors';
import { useUserStore } from '@/store/userStore';

export default function WelcomeScreen() {
  const router = useRouter();
  const login = useUserStore(state => state.login);
  
  const handleDemoLogin = async () => {
    try {
      await login({
        id: '1',
        email: 'demo@example.com',
        name: 'Demo User',
        preferences: {
          dailyGoal: 10,
          notifications: true,
          theme: 'light',
          language: 'en',
        }
      });
      router.replace('/(tabs)');
    } catch (error) {
      console.error('Demo login error:', error);
    }
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.header}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?q=80&w=1471&auto=format&fit=crop' }}
            style={styles.logo}
          />
          <Text style={styles.title}>VocabBoost</Text>
          <Text style={styles.subtitle}>Learn languages efficiently</Text>
        </View>
        
        <View style={styles.features}>
          <View style={styles.featureItem}>
            <View style={styles.featureIcon}>
              <Text style={styles.featureIconText}>📚</Text>
            </View>
            <View style={styles.featureTextContainer}>
              <Text style={styles.featureTitle}>Create Word Lists</Text>
              <Text style={styles.featureDescription}>
                Organize vocabulary by topics or difficulty
              </Text>
            </View>
          </View>
          
          <View style={styles.featureItem}>
            <View style={styles.featureIcon}>
              <Text style={styles.featureIconText}>🧠</Text>
            </View>
            <View style={styles.featureTextContainer}>
              <Text style={styles.featureTitle}>Smart Learning</Text>
              <Text style={styles.featureDescription}>
                Spaced repetition for efficient memorization
              </Text>
            </View>
          </View>
          
          <View style={styles.featureItem}>
            <View style={styles.featureIcon}>
              <Text style={styles.featureIconText}>📊</Text>
            </View>
            <View style={styles.featureTextContainer}>
              <Text style={styles.featureTitle}>Track Progress</Text>
              <Text style={styles.featureDescription}>
                Monitor your learning journey with detailed stats
              </Text>
            </View>
          </View>
        </View>
        
        <View style={styles.actions}>
          <Link href="/login">
            <Button
              title="Sign In"
              variant="primary"
              onPress={() => {}}
              style={styles.signInButton}
            />
          </Link>
          
          <Link href="/register">
            <Button
              title="Create Account"
              variant="outline"
              onPress={() => {}}
              style={styles.createAccountButton}
            />
          </Link>
          
          <View style={styles.demoContainer}>
            <Text style={styles.demoText}>Want to try first?</Text>
            <TouchableOpacity onPress={handleDemoLogin}>
              <Text style={styles.demoLink}>Use demo account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
    padding: 24,
    justifyContent: 'space-between',
  },
  header: {
    alignItems: 'center',
    marginTop: 20,
  },
  logo: {
    width: 120,
    height: 120,
    borderRadius: 24,
    marginBottom: 16,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  features: {
    marginVertical: 32,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  featureIconText: {
    fontSize: 24,
  },
  featureTextContainer: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  featureDescription: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  actions: {
    marginBottom: 20,
  },
  signInButton: {
    marginBottom: 12,
  },
  createAccountButton: {
    marginBottom: 20,
  },
  demoContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  demoText: {
    color: colors.textSecondary,
    marginRight: 4,
  },
  demoLink: {
    color: colors.primary,
    fontWeight: '600',
  },
});