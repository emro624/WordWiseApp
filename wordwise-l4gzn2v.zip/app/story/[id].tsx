import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { colors } from '@/constants/colors';
import { useStoryStore } from '@/store/storyStore';
import { useWordListsStore } from '@/store/wordListsStore';
import { getLanguageFlag, getLanguageName } from '@/mocks/languages';
import { 
  Volume2, 
  BookOpen, 
  ChevronDown, 
  ChevronUp,
  Check,
  BookmarkPlus,
  Share2,
  ThumbsUp,
  Pause,
  Plus,
  HelpCircle,
  Download,
  BookmarkCheck,
} from 'lucide-react-native';

export default function StoryScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const scrollViewRef = useRef<ScrollView>(null);
  
  const { 
    getStory, 
    markStoryAsRead, 
    isStoryRead, 
    bookmarkStory, 
    isStoryBookmarked,
    downloadStory,
    isStoryDownloaded,
    isLoading,
  } = useStoryStore(state => ({
    getStory: state.getStory,
    markStoryAsRead: state.markStoryAsRead,
    isStoryRead: state.isStoryRead,
    bookmarkStory: state.bookmarkStory,
    isStoryBookmarked: state.isStoryBookmarked,
    downloadStory: state.downloadStory,
    isStoryDownloaded: state.isStoryDownloaded,
    isLoading: state.isLoading,
  }));
  
  const { 
    getLists, 
    addWord,
  } = useWordListsStore(state => ({
    getLists: state.getLists,
    addWord: state.addWord,
  }));
  
  const story = getStory(id);
  const [showTranslation, setShowTranslation] = useState(false);
  const [showVocabulary, setShowVocabulary] = useState(false);
  const [showQuestions, setShowQuestions] = useState(false);
  const [highlightedWords, setHighlightedWords] = useState<string[]>([]);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isDownloaded, setIsDownloaded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentWordIndex, setCurrentWordIndex] = useState(-1);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  
  // Get user's word lists for the story language
  const userLists = getLists().filter(list => 
    story ? list.language === story.language : false
  );
  
  useEffect(() => {
    if (story && !isStoryRead(id)) {
      markStoryAsRead(id);
    }
    
    if (story) {
      setIsBookmarked(isStoryBookmarked(id));
      setIsDownloaded(isStoryDownloaded(id));
    }
  }, [story, id, isStoryRead, markStoryAsRead, isStoryBookmarked, isStoryDownloaded]);
  
  const toggleTranslation = () => {
    setShowTranslation(!showTranslation);
  };
  
  const toggleVocabulary = () => {
    setShowVocabulary(!showVocabulary);
    setShowQuestions(false);
  };
  
  const toggleQuestions = () => {
    setShowQuestions(!showQuestions);
    setShowVocabulary(false);
    
    // Reset answers when toggling questions
    if (!showQuestions) {
      setSelectedAnswers({});
      setShowResults(false);
    }
  };
  
  const highlightWord = (word: string) => {
    if (highlightedWords.includes(word)) {
      setHighlightedWords(highlightedWords.filter(w => w !== word));
    } else {
      setHighlightedWords([...highlightedWords, word]);
    }
  };
  
  const handleBookmark = () => {
    if (story) {
      bookmarkStory(id);
      setIsBookmarked(!isBookmarked);
    }
  };
  
  const handleDownload = () => {
    if (story) {
      downloadStory(id);
      setIsDownloaded(true);
      Alert.alert(
        "Story Downloaded",
        "This story is now available offline.",
        [{ text: "OK" }]
      );
    }
  };
  
  const handleShare = () => {
    // Share functionality would be implemented here
    Alert.alert("Share Story", "Sharing this story...");
  };
  
  const togglePlayback = () => {
    if (isPlaying) {
      // Stop playback
      setIsPlaying(false);
      setCurrentWordIndex(-1);
    } else {
      // Start playback
      setIsPlaying(true);
      setCurrentWordIndex(0);
      
      // Simulate text-to-speech by highlighting words
      let index = 0;
      const words = story?.content.split(' ') || [];
      
      const interval = setInterval(() => {
        if (index < words.length) {
          setCurrentWordIndex(index);
          index++;
        } else {
          clearInterval(interval);
          setIsPlaying(false);
          setCurrentWordIndex(-1);
        }
      }, 500); // Adjust speed as needed
      
      return () => clearInterval(interval);
    }
  };
  
  const handleSaveWord = (word: string, translation: string) => {
    if (userLists.length === 0) {
      Alert.alert(
        "No Word Lists",
        "You don't have any word lists for this language. Would you like to create one?",
        [
          { text: "Cancel", style: "cancel" },
          { 
            text: "Create List", 
            onPress: () => router.push({
              pathname: '/list/create',
              params: { language: story?.language }
            })
          }
        ]
      );
      return;
    }
    
    // If only one list exists, save to that list
    if (userLists.length === 1) {
      addWord({
        listId: userLists[0].id,
        original: word,
        translation: translation,
        example: "",
        pronunciation: "",
      });
      
      Alert.alert(
        "Word Saved",
        `"${word}" has been added to "${userLists[0].name}"`,
        [{ text: "OK" }]
      );
      return;
    }
    
    // If multiple lists exist, show a selection dialog
    Alert.alert(
      "Save Word",
      `Select a list to save "${word}"`,
      [
        { text: "Cancel", style: "cancel" },
        ...userLists.map(list => ({
          text: list.name,
          onPress: () => {
            addWord({
              listId: list.id,
              original: word,
              translation: translation,
              example: "",
              pronunciation: "",
            });
            
            Alert.alert(
              "Word Saved",
              `"${word}" has been added to "${list.name}"`,
              [{ text: "OK" }]
            );
          }
        }))
      ]
    );
  };
  
  const handleSelectAnswer = (questionIndex: number, answerIndex: number) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [questionIndex]: answerIndex
    });
  };
  
  const handleSubmitQuiz = () => {
    if (!story || !story.questions) return;
    
    // Check if all questions are answered
    if (Object.keys(selectedAnswers).length < story.questions.length) {
      Alert.alert(
        "Incomplete Quiz",
        "Please answer all questions before submitting.",
        [{ text: "OK" }]
      );
      return;
    }
    
    // Calculate score
    let correctCount = 0;
    story.questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correctCount++;
      }
    });
    
    const finalScore = Math.round((correctCount / story.questions.length) * 100);
    setScore(finalScore);
    setShowResults(true);
    
    // Scroll to results
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 300);
  };
  
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Loading story...</Text>
        </View>
      </SafeAreaView>
    );
  }
  
  if (!story) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>Story Not Found</Text>
          <Text style={styles.emptyDescription}>
            The story you are looking for does not exist.
          </Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            style={styles.emptyButton}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  const getLevelColor = () => {
    switch (story.level) {
      case 'beginner':
        return colors.success;
      case 'intermediate':
        return colors.warning;
      case 'advanced':
        return colors.error;
      default:
        return colors.primary;
    }
  };
  
  // Split content into words for highlighting during playback
  const contentWords = story.content.split(' ');
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: story.title,
          headerRight: () => (
            <View style={styles.headerActions}>
              <TouchableOpacity 
                onPress={handleBookmark}
                style={styles.headerButton}
              >
                {isBookmarked ? (
                  <BookmarkCheck size={24} color={colors.primary} />
                ) : (
                  <BookmarkPlus size={24} color={colors.text} />
                )}
              </TouchableOpacity>
              
              {!isDownloaded && (
                <TouchableOpacity 
                  onPress={handleDownload}
                  style={styles.headerButton}
                >
                  <Download size={24} color={colors.text} />
                </TouchableOpacity>
              )}
              
              <TouchableOpacity 
                onPress={handleShare}
                style={styles.headerButton}
              >
                <Share2 size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
          ),
        }} 
      />
      
      <ScrollView 
        ref={scrollViewRef}
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.storyHeader}>
          <Text style={styles.storyTitle}>{story.title}</Text>
          
          <View style={styles.storyInfo}>
            <View style={styles.languageInfo}>
              <Text style={styles.languageText}>
                {getLanguageFlag(story.language)} {getLanguageName(story.language)}
              </Text>
            </View>
            
            <View 
              style={[
                styles.levelBadge, 
                { backgroundColor: getLevelColor() }
              ]}
            >
              <Text style={styles.levelText}>
                {story.level.charAt(0).toUpperCase() + story.level.slice(1)}
              </Text>
            </View>
          </View>
          
          {isStoryRead(id) && (
            <View style={styles.readBadge}>
              <Check size={14} color="white" />
              <Text style={styles.readText}>Read</Text>
            </View>
          )}
          
          {isDownloaded && (
            <View style={[styles.downloadedBadge, styles.readBadge]}>
              <Download size={14} color="white" />
              <Text style={styles.readText}>Downloaded</Text>
            </View>
          )}
        </Card>
        
        <View style={styles.storyControls}>
          <TouchableOpacity 
            style={styles.controlButton}
            onPress={toggleTranslation}
          >
            <Text style={styles.controlText}>
              {showTranslation ? 'Hide Translation' : 'Show Translation'}
            </Text>
            {showTranslation ? (
              <ChevronUp size={16} color={colors.primary} />
            ) : (
              <ChevronDown size={16} color={colors.primary} />
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.controlButton}
            onPress={toggleVocabulary}
          >
            <Text style={styles.controlText}>
              {showVocabulary ? 'Hide Vocabulary' : 'Show Vocabulary'}
            </Text>
            {showVocabulary ? (
              <ChevronUp size={16} color={colors.primary} />
            ) : (
              <ChevronDown size={16} color={colors.primary} />
            )}
          </TouchableOpacity>
        </View>
        
        <Card style={styles.storyCard}>
          <View style={styles.storyContent}>
            <TouchableOpacity 
              style={styles.audioButton}
              onPress={togglePlayback}
            >
              {isPlaying ? (
                <Pause size={24} color={colors.primary} />
              ) : (
                <Volume2 size={24} color={colors.primary} />
              )}
            </TouchableOpacity>
            
            <Text style={styles.storyText}>
              {isPlaying ? (
                contentWords.map((word, index) => (
                  <Text
                    key={`${word}-${index}`}
                    style={[
                      index === currentWordIndex && styles.highlightedWord
                    ]}
                  >
                    {word}{' '}
                  </Text>
                ))
              ) : (
                story.content
              )}
            </Text>
          </View>
        </Card>
        
        {showTranslation && (
          <Card style={styles.translationCard}>
            <Text style={styles.translationTitle}>Translation</Text>
            <Text style={styles.translationText}>{story.translation}</Text>
          </Card>
        )}
        
        {showVocabulary && (
          <Card style={styles.vocabularyCard}>
            <View style={styles.vocabularyHeader}>
              <Text style={styles.vocabularyTitle}>Vocabulary</Text>
              <Text style={styles.vocabularySubtitle}>
                Tap a word to highlight it in the text
              </Text>
            </View>
            
            <View style={styles.vocabularyList}>
              {story.vocabulary.map((item, index) => (
                <TouchableOpacity 
                  key={index}
                  style={[
                    styles.vocabularyItem,
                    highlightedWords.includes(item.word) && styles.highlightedVocabularyItem,
                  ]}
                  onPress={() => highlightWord(item.word)}
                >
                  <View style={styles.vocabularyItemContent}>
                    <Text style={styles.vocabularyWord}>{item.word}</Text>
                    <Text style={styles.vocabularyTranslation}>
                      {item.translation}
                    </Text>
                  </View>
                  
                  <TouchableOpacity
                    style={styles.addWordButton}
                    onPress={() => handleSaveWord(item.word, item.translation)}
                  >
                    <Plus size={16} color={colors.primary} />
                  </TouchableOpacity>
                </TouchableOpacity>
              ))}
            </View>
          </Card>
        )}
        
        <View style={styles.quizSection}>
          <TouchableOpacity 
            style={styles.quizButton}
            onPress={toggleQuestions}
          >
            <Text style={styles.quizButtonText}>
              {showQuestions ? 'Hide Comprehension Quiz' : 'Take Comprehension Quiz'}
            </Text>
            {showQuestions ? (
              <ChevronUp size={16} color={colors.primary} />
            ) : (
              <ChevronDown size={16} color={colors.primary} />
            )}
          </TouchableOpacity>
          
          {showQuestions && story.questions && (
            <Card style={styles.questionsCard}>
              <Text style={styles.questionsTitle}>Comprehension Questions</Text>
              
              {story.questions.map((question, qIndex) => (
                <View key={qIndex} style={styles.questionContainer}>
                  <Text style={styles.questionText}>
                    {qIndex + 1}{". "}{question.text}
                  </Text>
                  
                  <View style={styles.answersContainer}>
                    {question.answers.map((answer, aIndex) => (
                      <TouchableOpacity
                        key={aIndex}
                        style={[
                          styles.answerButton,
                          selectedAnswers[qIndex] === aIndex && styles.selectedAnswerButton,
                          showResults && aIndex === question.correctAnswer && styles.correctAnswerButton,
                          showResults && selectedAnswers[qIndex] === aIndex && 
                          aIndex !== question.correctAnswer && styles.incorrectAnswerButton,
                        ]}
                        onPress={() => handleSelectAnswer(qIndex, aIndex)}
                        disabled={showResults}
                      >
                        <Text style={[
                          styles.answerText,
                          selectedAnswers[qIndex] === aIndex && styles.selectedAnswerText,
                          showResults && aIndex === question.correctAnswer && styles.correctAnswerText,
                          showResults && selectedAnswers[qIndex] === aIndex && 
                          aIndex !== question.correctAnswer && styles.incorrectAnswerText,
                        ]}>
                          {answer}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                  
                  {showResults && selectedAnswers[qIndex] !== question.correctAnswer && (
                    <View style={styles.explanationContainer}>
                      <Text style={styles.explanationText}>
                        <Text style={styles.explanationLabel}>Explanation: </Text>
                        {question.explanation}
                      </Text>
                    </View>
                  )}
                </View>
              ))}
              
              {!showResults ? (
                <Button
                  title="Submit Answers"
                  onPress={handleSubmitQuiz}
                  style={styles.submitButton}
                />
              ) : (
                <View style={styles.resultsContainer}>
                  <Text style={styles.resultsTitle}>
                    Your Score: {score}%
                  </Text>
                  <Text style={styles.resultsMessage}>
                    {score >= 80 
                      ? "Excellent! You have a great understanding of the story." 
                      : score >= 60 
                        ? "Good job! You understood most of the story." 
                        : "Keep practicing! Try reading the story again."}
                  </Text>
                </View>
              )}
            </Card>
          )}
        </View>
        
        <View style={styles.feedbackContainer}>
          <Text style={styles.feedbackTitle}>Was this story helpful?</Text>
          
          <View style={styles.feedbackButtons}>
            <TouchableOpacity style={styles.feedbackButton}>
              <ThumbsUp size={20} color={colors.primary} />
              <Text style={styles.feedbackButtonText}>Yes</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.feedbackButton}>
              <ThumbsUp size={20} color={colors.textSecondary} style={{ transform: [{ rotate: '180deg' }] }} />
              <Text style={styles.feedbackButtonText}>No</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.navigationButtons}>
          <Button
            title="More Stories"
            onPress={() => router.push('/stories')}
            variant="outline"
            leftIcon={<BookOpen size={20} color={colors.primary} />}
            style={styles.navigationButton}
          />
          
          <Button
            title="Practice Vocabulary"
            onPress={() => {
              if (userLists.length > 0) {
                router.push(`/learning/${userLists[0].id}`);
              } else {
                Alert.alert(
                  "No Word Lists",
                  "You don't have any word lists for this language. Would you like to create one?",
                  [
                    { text: "Cancel", style: "cancel" },
                    { 
                      text: "Create List", 
                      onPress: () => router.push({
                        pathname: '/list/create',
                        params: { language: story.language }
                      })
                    }
                  ]
                );
              }
            }}
            style={styles.navigationButton}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerButton: {
    paddingHorizontal: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  emptyButton: {
    minWidth: 150,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  storyHeader: {
    marginBottom: 16,
  },
  storyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 12,
  },
  storyInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  languageInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  languageText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  levelBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  levelText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  readBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.success,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    position: 'absolute',
    top: 16,
    right: 16,
    gap: 4,
  },
  downloadedBadge: {
    backgroundColor: colors.primary,
    top: 48,
  },
  readText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
  },
  storyControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 12,
  },
  controlButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 4,
  },
  controlText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  storyCard: {
    marginBottom: 16,
  },
  storyContent: {
    position: 'relative',
  },
  audioButton: {
    position: 'absolute',
    top: 0,
    right: 0,
    padding: 8,
  },
  storyText: {
    fontSize: 18,
    color: colors.text,
    lineHeight: 28,
  },
  highlightedWord: {
    backgroundColor: 'rgba(93, 105, 227, 0.2)',
    color: colors.primary,
    fontWeight: '600',
  },
  translationCard: {
    marginBottom: 16,
  },
  translationTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  translationText: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 24,
  },
  vocabularyCard: {
    marginBottom: 24,
  },
  vocabularyHeader: {
    marginBottom: 12,
  },
  vocabularyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  vocabularySubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  vocabularyList: {
    gap: 8,
  },
  vocabularyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
  },
  vocabularyItemContent: {
    flex: 1,
  },
  highlightedVocabularyItem: {
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderColor: colors.primary,
  },
  vocabularyWord: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  vocabularyTranslation: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 2,
  },
  addWordButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  quizSection: {
    marginBottom: 24,
  },
  quizButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    gap: 8,
    marginBottom: 16,
  },
  quizButtonText: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: '500',
  },
  questionsCard: {
    padding: 16,
  },
  questionsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  questionContainer: {
    marginBottom: 20,
  },
  questionText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 12,
  },
  answersContainer: {
    gap: 8,
  },
  answerButton: {
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
  },
  selectedAnswerButton: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
  },
  correctAnswerButton: {
    borderColor: colors.success,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
  },
  incorrectAnswerButton: {
    borderColor: colors.error,
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
  },
  answerText: {
    fontSize: 16,
    color: colors.text,
  },
  selectedAnswerText: {
    color: colors.primary,
    fontWeight: '500',
  },
  correctAnswerText: {
    color: colors.success,
    fontWeight: '500',
  },
  incorrectAnswerText: {
    color: colors.error,
    fontWeight: '500',
  },
  explanationContainer: {
    marginTop: 8,
    padding: 12,
    backgroundColor: 'rgba(255, 152, 0, 0.1)',
    borderRadius: 8,
  },
  explanationLabel: {
    fontWeight: '600',
  },
  explanationText: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 20,
  },
  submitButton: {
    marginTop: 16,
  },
  resultsContainer: {
    marginTop: 16,
    padding: 16,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 8,
    alignItems: 'center',
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.primary,
    marginBottom: 8,
  },
  resultsMessage: {
    fontSize: 16,
    color: colors.text,
    textAlign: 'center',
  },
  feedbackContainer: {
    marginBottom: 24,
    alignItems: 'center',
  },
  feedbackTitle: {
    fontSize: 16,
    color: colors.text,
    marginBottom: 12,
  },
  feedbackButtons: {
    flexDirection: 'row',
    gap: 16,
  },
  feedbackButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 8,
  },
  feedbackButtonText: {
    fontSize: 14,
    color: colors.text,
  },
  navigationButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  navigationButton: {
    flex: 1,
  },
});