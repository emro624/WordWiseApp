import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
  Switch,
  Platform,
  Alert,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Input } from '@/components/Input';
import { colors } from '@/constants/colors';
import { useReminderStore } from '@/store/reminderStore';
import { useWordListsStore } from '@/store/wordListsStore';
import { ReminderCard } from '@/components/ReminderCard';
import { 
  Bell, 
  Plus, 
  Clock, 
  Calendar, 
  Repeat,
  ChevronDown,
  ChevronUp,
  Brain,
  ListChecks,
  Check,
  Info,
} from 'lucide-react-native';

// Days of the week
const daysOfWeek = [
  { id: 0, name: 'Sunday', short: 'Sun' },
  { id: 1, name: 'Monday', short: 'Mon' },
  { id: 2, name: 'Tuesday', short: 'Tue' },
  { id: 3, name: 'Wednesday', short: 'Wed' },
  { id: 4, name: 'Thursday', short: 'Thu' },
  { id: 5, name: 'Friday', short: 'Fri' },
  { id: 6, name: 'Saturday', short: 'Sat' },
];

export default function CreateReminderScreen() {
  const router = useRouter();
  const { reminders, addReminder, deleteReminder, toggleReminder } = useReminderStore(state => ({
    reminders: state.getReminders(),
    addReminder: state.addReminder,
    deleteReminder: state.deleteReminder,
    toggleReminder: state.toggleReminder,
  }));
  
  const wordLists = useWordListsStore(state => state.getLists());
  
  const [title, setTitle] = useState('Vocabulary Practice');
  const [message, setMessage] = useState('Time to practice your vocabulary!');
  const [time, setTime] = useState('08:00');
  const [selectedDays, setSelectedDays] = useState<number[]>([1, 2, 3, 4, 5]); // Mon-Fri by default
  const [isEnabled, setIsEnabled] = useState(true);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [reminderType, setReminderType] = useState<'daily' | 'custom' | 'smart'>('smart');
  const [selectedListId, setSelectedListId] = useState<string | undefined>(undefined);
  const [showListPicker, setShowListPicker] = useState(false);
  const [dailyGoal, setDailyGoal] = useState(20);
  const [showInfoModal, setShowInfoModal] = useState(false);
  
  const handleAddReminder = () => {
    if (!title.trim()) {
      Alert.alert("Error", "Please enter a reminder title");
      return;
    }
    
    addReminder({
      title,
      message,
      time,
      days: selectedDays,
      enabled: isEnabled,
      type: reminderType,
      listId: selectedListId,
      dailyGoal: reminderType === 'smart' ? dailyGoal : undefined,
    });
    
    // Reset form
    setTitle('Vocabulary Practice');
    setMessage('Time to practice your vocabulary!');
    setTime('08:00');
    setSelectedDays([1, 2, 3, 4, 5]);
    setIsEnabled(true);
    setReminderType('smart');
    setSelectedListId(undefined);
    setDailyGoal(20);
    
    Alert.alert(
      "Reminder Created",
      "Your reminder has been set successfully.",
      [{ text: "OK" }]
    );
  };
  
  const handleDeleteReminder = (id: string) => {
    Alert.alert(
      "Delete Reminder",
      "Are you sure you want to delete this reminder?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Delete", 
          onPress: () => deleteReminder(id),
          style: "destructive"
        }
      ]
    );
  };
  
  const handleToggleReminder = (id: string) => {
    toggleReminder(id);
  };
  
  const toggleDay = (dayId: number) => {
    if (selectedDays.includes(dayId)) {
      setSelectedDays(selectedDays.filter(id => id !== dayId));
    } else {
      setSelectedDays([...selectedDays, dayId]);
    }
  };
  
  const handleTimeChange = (newTime: string) => {
    setTime(newTime);
    setShowTimePicker(false);
  };
  
  const handleSelectList = (listId: string | undefined) => {
    setSelectedListId(listId);
    setShowListPicker(false);
  };
  
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  };
  
  const formatDays = (days: number[]) => {
    if (days.length === 7) return 'Every day';
    if (days.length === 0) return 'Never';
    if (days.length === 5 && days.every(day => day >= 1 && day <= 5)) return 'Weekdays';
    if (days.length === 2 && days.includes(0) && days.includes(6)) return 'Weekends';
    
    return days
      .sort((a, b) => a - b)
      .map(day => daysOfWeek.find(d => d.id === day)?.short)
      .join(', ');
  };
  
  const getListName = (listId: string | undefined) => {
    if (!listId) return 'All Lists';
    const list = wordLists.find(l => l.id === listId);
    return list ? list.name : 'Unknown List';
  };
  
  const showSmartReminderInfo = () => {
    setShowInfoModal(true);
    Alert.alert(
      "Smart Reminders",
      "Smart reminders use spaced repetition to help you learn more effectively. They prioritize words you're likely to forget based on your learning history and schedule reminders at optimal intervals.",
      [{ text: "Got it" }]
    );
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen options={{ title: 'Reminders' }} />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.newReminderCard}>
          <View style={styles.cardHeader}>
            <View style={styles.iconContainer}>
              <Bell size={24} color={colors.primary} />
            </View>
            <Text style={styles.cardTitle}>New Reminder</Text>
          </View>
          
          <Input
            label="Title"
            value={title}
            onChangeText={setTitle}
            placeholder="Reminder title"
          />
          
          <Input
            label="Message"
            value={message}
            onChangeText={setMessage}
            placeholder="Reminder message"
            multiline
            numberOfLines={2}
          />
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Reminder Type</Text>
            
            <View style={styles.reminderTypeContainer}>
              <TouchableOpacity
                style={[
                  styles.typeButton,
                  reminderType === 'daily' && styles.selectedTypeButton
                ]}
                onPress={() => setReminderType('daily')}
              >
                <Calendar size={20} color={reminderType === 'daily' ? colors.primary : colors.textSecondary} />
                <Text style={[
                  styles.typeButtonText,
                  reminderType === 'daily' && styles.selectedTypeText
                ]}>
                  Daily
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.typeButton,
                  reminderType === 'custom' && styles.selectedTypeButton
                ]}
                onPress={() => setReminderType('custom')}
              >
                <ListChecks size={20} color={reminderType === 'custom' ? colors.primary : colors.textSecondary} />
                <Text style={[
                  styles.typeButtonText,
                  reminderType === 'custom' && styles.selectedTypeText
                ]}>
                  Custom
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.typeButton,
                  reminderType === 'smart' && styles.selectedTypeButton
                ]}
                onPress={() => setReminderType('smart')}
              >
                <Brain size={20} color={reminderType === 'smart' ? colors.primary : colors.textSecondary} />
                <Text style={[
                  styles.typeButtonText,
                  reminderType === 'smart' && styles.selectedTypeText
                ]}>
                  Smart
                </Text>
              </TouchableOpacity>
            </View>
            
            {reminderType === 'smart' && (
              <TouchableOpacity 
                style={styles.infoButton}
                onPress={showSmartReminderInfo}
              >
                <Info size={16} color={colors.primary} />
                <Text style={styles.infoText}>
                  What are Smart Reminders?
                </Text>
              </TouchableOpacity>
            )}
          </View>
          
          {(reminderType === 'custom' || reminderType === 'smart') && (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Word List</Text>
              <TouchableOpacity 
                style={styles.selector}
                onPress={() => setShowListPicker(!showListPicker)}
              >
                <View style={styles.selectorContent}>
                  <ListChecks size={20} color={colors.textSecondary} />
                  <Text style={styles.selectorText}>
                    {selectedListId ? getListName(selectedListId) : 'All Lists'}
                  </Text>
                </View>
                
                {showListPicker ? (
                  <ChevronUp size={20} color={colors.textSecondary} />
                ) : (
                  <ChevronDown size={20} color={colors.textSecondary} />
                )}
              </TouchableOpacity>
              
              {showListPicker && (
                <View style={styles.dropdownContainer}>
                  <TouchableOpacity 
                    style={styles.dropdownItem}
                    onPress={() => handleSelectList(undefined)}
                  >
                    <Text style={styles.dropdownText}>All Lists</Text>
                    {!selectedListId && <Check size={16} color={colors.primary} />}
                  </TouchableOpacity>
                  
                  {wordLists.map(list => (
                    <TouchableOpacity 
                      key={list.id}
                      style={styles.dropdownItem}
                      onPress={() => handleSelectList(list.id)}
                    >
                      <Text style={styles.dropdownText}>{list.name}</Text>
                      {selectedListId === list.id && <Check size={16} color={colors.primary} />}
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>
          )}
          
          {reminderType === 'smart' && (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Daily Goal</Text>
              <View style={styles.goalContainer}>
                <TouchableOpacity 
                  style={styles.goalButton}
                  onPress={() => setDailyGoal(Math.max(5, dailyGoal - 5))}
                >
                  <Text style={styles.goalButtonText}>-</Text>
                </TouchableOpacity>
                
                <View style={styles.goalValue}>
                  <Text style={styles.goalValueText}>{dailyGoal} words</Text>
                </View>
                
                <TouchableOpacity 
                  style={styles.goalButton}
                  onPress={() => setDailyGoal(Math.min(100, dailyGoal + 5))}
                >
                  <Text style={styles.goalButtonText}>+</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Time</Text>
            <TouchableOpacity 
              style={styles.selector}
              onPress={() => setShowTimePicker(!showTimePicker)}
            >
              <View style={styles.selectorContent}>
                <Clock size={20} color={colors.textSecondary} />
                <Text style={styles.selectorText}>{formatTime(time)}</Text>
              </View>
              
              {showTimePicker ? (
                <ChevronUp size={20} color={colors.textSecondary} />
              ) : (
                <ChevronDown size={20} color={colors.textSecondary} />
              )}
            </TouchableOpacity>
            
            {showTimePicker && (
              <View style={styles.timePickerContainer}>
                <ScrollView 
                  horizontal 
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.timePicker}
                >
                  {Array.from({ length: 24 }).map((_, hour) => 
                    Array.from({ length: 4 }).map((_, minuteIdx) => {
                      const minute = minuteIdx * 15;
                      const timeValue = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                      return (
                        <TouchableOpacity
                          key={timeValue}
                          style={[
                            styles.timeOption,
                            time === timeValue && styles.selectedTimeOption
                          ]}
                          onPress={() => handleTimeChange(timeValue)}
                        >
                          <Text 
                            style={[
                              styles.timeOptionText,
                              time === timeValue && styles.selectedTimeOptionText
                            ]}
                          >
                            {formatTime(timeValue)}
                          </Text>
                        </TouchableOpacity>
                      );
                    })
                  )}
                </ScrollView>
              </View>
            )}
          </View>
          
          <View style={styles.formGroup}>
            <Text style={styles.label}>Repeat</Text>
            <View style={styles.daysContainer}>
              {daysOfWeek.map(day => (
                <TouchableOpacity
                  key={day.id}
                  style={[
                    styles.dayButton,
                    selectedDays.includes(day.id) && styles.selectedDayButton
                  ]}
                  onPress={() => toggleDay(day.id)}
                >
                  <Text 
                    style={[
                      styles.dayButtonText,
                      selectedDays.includes(day.id) && styles.selectedDayButtonText
                    ]}
                  >
                    {day.short}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          <View style={styles.formGroup}>
            <View style={styles.enabledContainer}>
              <View style={styles.enabledLeft}>
                <Bell size={20} color={colors.textSecondary} />
                <Text style={styles.enabledText}>Enable Reminder</Text>
              </View>
              
              <Switch
                value={isEnabled}
                onValueChange={setIsEnabled}
                trackColor={{ false: '#e9ecef', true: colors.primary }}
                thumbColor="white"
              />
            </View>
          </View>
          
          <Button
            title="Add Reminder"
            onPress={handleAddReminder}
            leftIcon={<Plus size={20} color="white" />}
          />
        </Card>
        
        <View style={styles.remindersSection}>
          <Text style={styles.sectionTitle}>Your Reminders</Text>
          
          {reminders.length === 0 ? (
            <Card style={styles.emptyCard}>
              <View style={styles.emptyContent}>
                <Bell size={40} color={colors.textSecondary} />
                <Text style={styles.emptyTitle}>No reminders yet</Text>
                <Text style={styles.emptyDescription}>
                  Add reminders to help you stay consistent with your learning
                </Text>
              </View>
            </Card>
          ) : (
            reminders.map(reminder => (
              <ReminderCard
                key={reminder.id}
                reminder={reminder}
                onToggle={() => handleToggleReminder(reminder.id)}
                onDelete={() => handleDeleteReminder(reminder.id)}
                onEdit={() => router.push(`/reminder/edit/${reminder.id}`)}
                formatTime={formatTime}
                formatDays={formatDays}
                getListName={getListName}
              />
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  newReminderCard: {
    marginBottom: 24,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  formGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
  },
  reminderTypeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  typeButton: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
    gap: 8,
  },
  selectedTypeButton: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
  },
  typeButtonText: {
    fontSize: 14,
    color: colors.text,
  },
  selectedTypeText: {
    color: colors.primary,
    fontWeight: '500',
  },
  infoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 4,
  },
  infoText: {
    fontSize: 14,
    color: colors.primary,
  },
  selector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    backgroundColor: 'white',
  },
  selectorContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  selectorText: {
    fontSize: 16,
    color: colors.text,
  },
  dropdownContainer: {
    marginTop: 8,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
    maxHeight: 200,
  },
  dropdownItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  dropdownText: {
    fontSize: 16,
    color: colors.text,
  },
  goalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  goalButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.primary,
  },
  goalValue: {
    flex: 1,
    alignItems: 'center',
  },
  goalValueText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  timePickerContainer: {
    marginTop: 8,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
    padding: 8,
  },
  timePicker: {
    paddingVertical: 8,
  },
  timeOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    marginHorizontal: 4,
  },
  selectedTimeOption: {
    backgroundColor: colors.primary,
  },
  timeOptionText: {
    fontSize: 14,
    color: colors.text,
  },
  selectedTimeOptionText: {
    color: 'white',
    fontWeight: '500',
  },
  daysContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  dayButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  selectedDayButton: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  dayButtonText: {
    fontSize: 12,
    color: colors.text,
  },
  selectedDayButtonText: {
    color: 'white',
    fontWeight: '500',
  },
  enabledContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  enabledLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  enabledText: {
    fontSize: 16,
    color: colors.text,
  },
  remindersSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
    marginLeft: 4,
  },
  emptyCard: {
    padding: 24,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});