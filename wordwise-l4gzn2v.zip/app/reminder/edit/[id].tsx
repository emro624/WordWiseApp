import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
  Switch,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Input } from '@/components/Input';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { colors } from '@/constants/colors';
import { useReminderStore } from '@/store/reminderStore';
import { useWordListsStore } from '@/store/wordListsStore';
import { 
  Check, 
  Brain, 
  Calendar, 
  ListChecks, 
  ChevronDown, 
  ChevronUp,
  Clock,
  Info,
} from 'lucide-react-native';

export default function EditReminderScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  const { getReminder, updateReminder } = useReminderStore(state => ({
    getReminder: state.getReminder,
    updateReminder: state.updateReminder,
  }));
  
  const lists = useWordListsStore(state => state.getLists());
  const reminder = getReminder(id);
  
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [time, setTime] = useState('09:00');
  const [days, setDays] = useState<number[]>([]);
  const [type, setType] = useState<'daily' | 'custom' | 'smart'>('daily');
  const [listId, setListId] = useState<string | undefined>(undefined);
  const [enabled, setEnabled] = useState(true);
  const [dailyGoal, setDailyGoal] = useState(20);
  
  const [showListSelector, setShowListSelector] = useState(false);
  const [showTimeSelector, setShowTimeSelector] = useState(false);
  
  const [errors, setErrors] = useState({
    title: '',
    message: '',
  });
  
  useEffect(() => {
    if (reminder) {
      setTitle(reminder.title || 'Vocabulary Practice');
      setMessage(reminder.message || 'Time to practice your vocabulary!');
      setTime(reminder.time);
      setDays(reminder.days);
      setType(reminder.type || 'daily');
      setListId(reminder.listId);
      setEnabled(reminder.enabled);
      setDailyGoal(reminder.dailyGoal || 20);
    }
  }, [reminder]);
  
  const validateForm = () => {
    const newErrors = {
      title: '',
      message: '',
    };
    
    if (!title.trim()) {
      newErrors.title = 'Title is required';
    }
    
    if (!message.trim()) {
      newErrors.message = 'Message is required';
    }
    
    setErrors(newErrors);
    
    return !newErrors.title && !newErrors.message;
  };
  
  const handleUpdateReminder = () => {
    if (!validateForm()) return;
    
    updateReminder(id, {
      title,
      message,
      time,
      days,
      type,
      listId,
      enabled,
      dailyGoal: type === 'smart' ? dailyGoal : undefined,
    });
    
    Alert.alert(
      "Reminder Updated",
      "Your reminder has been updated successfully.",
      [{ 
        text: "OK",
        onPress: () => router.back()
      }]
    );
  };
  
  const toggleDay = (day: number) => {
    if (days.includes(day)) {
      setDays(days.filter(d => d !== day));
    } else {
      setDays([...days, day].sort());
    }
  };
  
  const toggleAllDays = () => {
    if (days.length === 7) {
      setDays([]);
    } else {
      setDays([0, 1, 2, 3, 4, 5, 6]);
    }
  };
  
  const toggleListSelector = () => {
    setShowListSelector(!showListSelector);
  };
  
  const selectList = (id: string | undefined) => {
    setListId(id);
    setShowListSelector(false);
  };
  
  const handleTimeChange = (newTime: string) => {
    setTime(newTime);
    setShowTimeSelector(false);
  };
  
  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours, 10);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minutes} ${ampm}`;
  };
  
  const showSmartReminderInfo = () => {
    Alert.alert(
      "Smart Reminders",
      "Smart reminders use spaced repetition to help you learn more effectively. They prioritize words you're likely to forget based on your learning history and schedule reminders at optimal intervals.",
      [{ text: "Got it" }]
    );
  };
  
  if (!reminder) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Reminder not found</Text>
        <Button
          title="Go Back"
          onPress={() => router.back()}
          style={styles.errorButton}
        />
      </View>
    );
  }
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: 'Edit Reminder',
          headerRight: () => (
            <TouchableOpacity 
              onPress={handleUpdateReminder}
              style={styles.headerButton}
            >
              <Text style={styles.headerButtonText}>Save</Text>
            </TouchableOpacity>
          ),
        }} 
      />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Input
          label="Title"
          placeholder="Reminder title"
          value={title}
          onChangeText={setTitle}
          error={errors.title}
        />
        
        <Input
          label="Message"
          placeholder="Reminder message"
          value={message}
          onChangeText={setMessage}
          multiline
          numberOfLines={2}
          error={errors.message}
        />
        
        <View style={styles.section}>
          <Text style={styles.label}>Reminder Type</Text>
          
          <View style={styles.reminderTypeContainer}>
            <TouchableOpacity
              style={[
                styles.typeButton,
                type === 'daily' && styles.selectedTypeButton
              ]}
              onPress={() => setType('daily')}
            >
              <Calendar size={20} color={type === 'daily' ? colors.primary : colors.textSecondary} />
              <Text style={[
                styles.typeButtonText,
                type === 'daily' && styles.selectedTypeText
              ]}>
                Daily
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeButton,
                type === 'custom' && styles.selectedTypeButton
              ]}
              onPress={() => setType('custom')}
            >
              <ListChecks size={20} color={type === 'custom' ? colors.primary : colors.textSecondary} />
              <Text style={[
                styles.typeButtonText,
                type === 'custom' && styles.selectedTypeText
              ]}>
                Custom
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.typeButton,
                type === 'smart' && styles.selectedTypeButton
              ]}
              onPress={() => setType('smart')}
            >
              <Brain size={20} color={type === 'smart' ? colors.primary : colors.textSecondary} />
              <Text style={[
                styles.typeButtonText,
                type === 'smart' && styles.selectedTypeText
              ]}>
                Smart
              </Text>
            </TouchableOpacity>
          </View>
          
          {type === 'smart' && (
            <TouchableOpacity 
              style={styles.infoButton}
              onPress={showSmartReminderInfo}
            >
              <Info size={16} color={colors.primary} />
              <Text style={styles.infoText}>
                What are Smart Reminders?
              </Text>
            </TouchableOpacity>
          )}
        </View>
        
        {(type === 'custom' || type === 'smart') && (
          <View style={styles.section}>
            <Text style={styles.label}>Word List (Optional)</Text>
            
            <TouchableOpacity 
              style={styles.selector}
              onPress={toggleListSelector}
            >
              <View style={styles.selectorContent}>
                <ListChecks size={20} color={colors.textSecondary} />
                <Text style={styles.selectorText}>
                  {listId 
                    ? lists.find(list => list.id === listId)?.name || 'Select List'
                    : 'All Lists'}
                </Text>
              </View>
              
              {showListSelector ? (
                <ChevronUp size={20} color={colors.textSecondary} />
              ) : (
                <ChevronDown size={20} color={colors.textSecondary} />
              )}
            </TouchableOpacity>
            
            {showListSelector && (
              <Card style={styles.dropdown}>
                <TouchableOpacity
                  style={styles.dropdownOption}
                  onPress={() => selectList(undefined)}
                >
                  <Text style={styles.dropdownText}>All Lists</Text>
                  {!listId && <Check size={16} color={colors.primary} />}
                </TouchableOpacity>
                
                {lists.map(list => (
                  <TouchableOpacity
                    key={list.id}
                    style={styles.dropdownOption}
                    onPress={() => selectList(list.id)}
                  >
                    <Text style={styles.dropdownText}>{list.name}</Text>
                    {listId === list.id && <Check size={16} color={colors.primary} />}
                  </TouchableOpacity>
                ))}
              </Card>
            )}
          </View>
        )}
        
        {type === 'smart' && (
          <View style={styles.section}>
            <Text style={styles.label}>Daily Goal</Text>
            <View style={styles.goalContainer}>
              <TouchableOpacity 
                style={styles.goalButton}
                onPress={() => setDailyGoal(Math.max(5, dailyGoal - 5))}
              >
                <Text style={styles.goalButtonText}>-</Text>
              </TouchableOpacity>
              
              <View style={styles.goalValue}>
                <Text style={styles.goalValueText}>{dailyGoal} words</Text>
              </View>
              
              <TouchableOpacity 
                style={styles.goalButton}
                onPress={() => setDailyGoal(Math.min(100, dailyGoal + 5))}
              >
                <Text style={styles.goalButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        <View style={styles.section}>
          <Text style={styles.label}>Time</Text>
          
          <TouchableOpacity 
            style={styles.selector}
            onPress={() => setShowTimeSelector(!showTimeSelector)}
          >
            <View style={styles.selectorContent}>
              <Clock size={20} color={colors.textSecondary} />
              <Text style={styles.selectorText}>{formatTime(time)}</Text>
            </View>
            
            {showTimeSelector ? (
              <ChevronUp size={20} color={colors.textSecondary} />
            ) : (
              <ChevronDown size={20} color={colors.textSecondary} />
            )}
          </TouchableOpacity>
          
          {showTimeSelector && (
            <Card style={styles.dropdown}>
              {['08:00', '09:00', '12:00', '15:00', '18:00', '20:00', '21:00'].map(t => (
                <TouchableOpacity
                  key={t}
                  style={styles.dropdownOption}
                  onPress={() => handleTimeChange(t)}
                >
                  <Text style={styles.dropdownText}>{formatTime(t)}</Text>
                  {time === t && <Check size={16} color={colors.primary} />}
                </TouchableOpacity>
              ))}
            </Card>
          )}
        </View>
        
        <View style={styles.section}>
          <View style={styles.daysHeader}>
            <Text style={styles.label}>Days</Text>
            
            <TouchableOpacity onPress={toggleAllDays}>
              <Text style={styles.toggleAllText}>
                {days.length === 7 ? 'Deselect All' : 'Select All'}
              </Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.daysContainer}>
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
              <TouchableOpacity
                key={day}
                style={[
                  styles.dayButton,
                  days.includes(index) && styles.selectedDay,
                ]}
                onPress={() => toggleDay(index)}
              >
                <Text style={[
                  styles.dayText,
                  days.includes(index) && styles.selectedDayText,
                ]}>
                  {day}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.enabledContainer}>
            <Text style={styles.label}>Enabled</Text>
            <Switch
              value={enabled}
              onValueChange={setEnabled}
              trackColor={{ false: '#e9ecef', true: colors.primary }}
              thumbColor="white"
            />
          </View>
        </View>
        
        <Button
          title="Save Changes"
          onPress={handleUpdateReminder}
          style={styles.saveButton}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  headerButtonText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  section: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
  },
  reminderTypeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 8,
  },
  typeButton: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
    gap: 8,
  },
  selectedTypeButton: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
  },
  typeButtonText: {
    fontSize: 14,
    color: colors.text,
  },
  selectedTypeText: {
    color: colors.primary,
    fontWeight: '500',
  },
  infoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 4,
  },
  infoText: {
    fontSize: 14,
    color: colors.primary,
  },
  selector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    backgroundColor: 'white',
  },
  selectorContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  selectorText: {
    fontSize: 16,
    color: colors.text,
  },
  dropdown: {
    marginTop: 8,
    maxHeight: 200,
  },
  dropdownOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  dropdownText: {
    fontSize: 16,
    color: colors.text,
  },
  goalContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  goalButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.primary,
  },
  goalValue: {
    flex: 1,
    alignItems: 'center',
  },
  goalValueText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  daysHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  toggleAllText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  daysContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  dayButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
  },
  selectedDay: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  dayText: {
    fontSize: 12,
    color: colors.text,
  },
  selectedDayText: {
    color: 'white',
    fontWeight: '600',
  },
  enabledContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  saveButton: {
    marginBottom: 24,
  },
  errorText: {
    fontSize: 18,
    color: colors.text,
    textAlign: 'center',
    marginTop: 24,
  },
  errorButton: {
    marginTop: 16,
    alignSelf: 'center',
    width: 150,
  },
});