import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Input } from '@/components/Input';
import { Button } from '@/components/Button';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';

export default function EditWordScreen() {
  const { id, listId } = useLocalSearchParams<{ id: string; listId: string }>();
  const router = useRouter();
  
  const { getList, getWord, updateWord } = useWordListsStore(state => ({
    getList: state.getList,
    getWord: state.getWord,
    updateWord: state.updateWord,
  }));
  
  const list = getList(listId);
  const word = getWord(listId, id);
  
  const [original, setOriginal] = useState('');
  const [translation, setTranslation] = useState('');
  const [pronunciation, setPronunciation] = useState('');
  const [example, setExample] = useState('');
  const [notes, setNotes] = useState('');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  
  const [errors, setErrors] = useState({
    original: '',
    translation: '',
  });
  
  useEffect(() => {
    if (word) {
      setOriginal(word.original);
      setTranslation(word.translation);
      setPronunciation(word.pronunciation || '');
      setExample(word.example || '');
      setNotes(word.notes || '');
      setDifficulty(word.difficulty);
    }
  }, [word]);
  
  const validateForm = () => {
    const newErrors = {
      original: '',
      translation: '',
    };
    
    if (!original.trim()) {
      newErrors.original = 'Word is required';
    }
    
    if (!translation.trim()) {
      newErrors.translation = 'Translation is required';
    }
    
    setErrors(newErrors);
    
    return !newErrors.original && !newErrors.translation;
  };
  
  const handleUpdateWord = () => {
    if (!validateForm()) return;
    
    updateWord(listId, id, {
      original,
      translation,
      pronunciation,
      example,
      notes,
      difficulty,
    });
    
    router.back();
  };
  
  if (!list || !word) {
    return (
      <View style={styles.container}>
        <Text>Word not found</Text>
      </View>
    );
  }
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: 'Edit Word',
          headerRight: () => (
            <TouchableOpacity 
              onPress={handleUpdateWord}
              style={styles.headerButton}
            >
              <Text style={styles.headerButtonText}>Save</Text>
            </TouchableOpacity>
          ),
        }} 
      />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.listInfo}>
          <Text style={styles.listInfoText}>
            Editing in: <Text style={styles.listName}>{list.name}</Text>
          </Text>
        </View>
        
        <Input
          label="Word"
          placeholder={`Word in ${list.language}`}
          value={original}
          onChangeText={setOriginal}
          error={errors.original}
        />
        
        <Input
          label="Translation"
          placeholder={`Translation in ${list.targetLanguage}`}
          value={translation}
          onChangeText={setTranslation}
          error={errors.translation}
        />
        
        <Input
          label="Pronunciation (optional)"
          placeholder="How to pronounce the word"
          value={pronunciation}
          onChangeText={setPronunciation}
        />
        
        <Input
          label="Example (optional)"
          placeholder="Example sentence using the word"
          value={example}
          onChangeText={setExample}
          multiline
          numberOfLines={2}
        />
        
        <Input
          label="Notes (optional)"
          placeholder="Any additional notes about the word"
          value={notes}
          onChangeText={setNotes}
          multiline
          numberOfLines={2}
        />
        
        <View style={styles.difficultySection}>
          <Text style={styles.label}>Difficulty</Text>
          
          <View style={styles.difficultyOptions}>
            <TouchableOpacity
              style={[
                styles.difficultyOption,
                difficulty === 'easy' && styles.selectedDifficulty,
                difficulty === 'easy' && { backgroundColor: colors.success + '20' },
              ]}
              onPress={() => setDifficulty('easy')}
            >
              <Text style={[
                styles.difficultyText,
                difficulty === 'easy' && { color: colors.success },
              ]}>
                Easy
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.difficultyOption,
                difficulty === 'medium' && styles.selectedDifficulty,
                difficulty === 'medium' && { backgroundColor: colors.warning + '20' },
              ]}
              onPress={() => setDifficulty('medium')}
            >
              <Text style={[
                styles.difficultyText,
                difficulty === 'medium' && { color: colors.warning },
              ]}>
                Medium
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.difficultyOption,
                difficulty === 'hard' && styles.selectedDifficulty,
                difficulty === 'hard' && { backgroundColor: colors.error + '20' },
              ]}
              onPress={() => setDifficulty('hard')}
            >
              <Text style={[
                styles.difficultyText,
                difficulty === 'hard' && { color: colors.error },
              ]}>
                Hard
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <Button
          title="Save Changes"
          onPress={handleUpdateWord}
          style={styles.saveButton}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  headerButtonText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  listInfo: {
    marginBottom: 16,
    padding: 12,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 8,
  },
  listInfoText: {
    fontSize: 14,
    color: colors.text,
  },
  listName: {
    fontWeight: '600',
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
  },
  difficultySection: {
    marginBottom: 24,
  },
  difficultyOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  difficultyOption: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    alignItems: 'center',
  },
  selectedDifficulty: {
    borderWidth: 2,
  },
  difficultyText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.textSecondary,
  },
  saveButton: {
    marginBottom: 24,
  },
});