import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StoryCard } from '@/components/StoryCard';
import { EmptyState } from '@/components/EmptyState';
import { colors } from '@/constants/colors';
import { useStoryStore } from '@/store/storyStore';
import { 
  BookmarkCheck,
  BookOpen,
} from 'lucide-react-native';

export default function BookmarkedStoriesScreen() {
  const router = useRouter();
  const { 
    getBookmarkedStories, 
    isStoryRead, 
    bookmarkStory,
    isStoryDownloaded,
  } = useStoryStore(state => ({
    getBookmarkedStories: state.getBookmarkedStories,
    isStoryRead: state.isStoryRead,
    bookmarkStory: state.bookmarkStory,
    isStoryDownloaded: state.isStoryDownloaded,
  }));
  
  const bookmarkedStories = getBookmarkedStories();
  
  const handleStoryPress = (storyId: string) => {
    router.push(`/story/${storyId}`);
  };
  
  const handleRemoveBookmark = (storyId: string) => {
    bookmarkStory(storyId);
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen options={{ title: 'Bookmarked Stories' }} />
      
      {bookmarkedStories.length === 0 ? (
        <EmptyState
          title="No Bookmarked Stories"
          description="You haven't bookmarked any stories yet. Bookmark stories to easily find them later."
          icon={<BookmarkCheck size={64} color={colors.textSecondary} />}
          actionLabel="Browse Stories"
          onAction={() => router.push('/stories')}
        />
      ) : (
        <FlatList
          data={bookmarkedStories}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <View style={styles.storyItem}>
              <StoryCard
                story={item}
                isRead={isStoryRead(item.id)}
                isBookmarked={true}
                isDownloaded={isStoryDownloaded(item.id)}
                onPress={() => handleStoryPress(item.id)}
              />
              <TouchableOpacity 
                style={styles.removeButton}
                onPress={() => handleRemoveBookmark(item.id)}
              >
                <Text style={styles.removeText}>Remove</Text>
              </TouchableOpacity>
            </View>
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  listContent: {
    padding: 16,
  },
  storyItem: {
    position: 'relative',
  },
  removeButton: {
    position: 'absolute',
    bottom: 24,
    right: 16,
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
    zIndex: 10,
  },
  removeText: {
    fontSize: 12,
    color: colors.error,
    fontWeight: '500',
  },
});