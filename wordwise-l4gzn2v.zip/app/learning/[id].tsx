import React, { useState, useEffect, useMemo } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  Alert,
  TextInput,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';
import { Word } from '@/types';
import { 
  ArrowLeft, 
  ArrowRight, 
  Volume2, 
  Check, 
  X,
  RotateCcw,
  Shuffle,
  HelpCircle,
  BookOpen,
  Keyboard,
  ListChecks,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

// Exercise types
type ExerciseType = 'flashcard' | 'typing' | 'multipleChoice' | 'matching';

export default function LearningScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  const { list, words, updateWordProgress } = useWordListsStore(state => ({
    list: state.getList(id),
    words: state.getWords(id),
    updateWordProgress: state.updateWordProgress,
  }));
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [learningWords, setLearningWords] = useState<Word[]>([]);
  const [results, setResults] = useState<{ wordId: string; correct: boolean }[]>([]);
  const [exerciseType, setExerciseType] = useState<ExerciseType>('flashcard');
  const [userAnswer, setUserAnswer] = useState('');
  const [showHint, setShowHint] = useState(false);
  const [options, setOptions] = useState<string[]>([]);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [matchingPairs, setMatchingPairs] = useState<{id: string, text: string, matched: boolean, selected: boolean}[]>([]);
  const [firstSelected, setFirstSelected] = useState<string | null>(null);
  
  const flipAnim = useState(new Animated.Value(0))[0];
  
  useEffect(() => {
    if (words.length > 0) {
      // Prioritize words that need more practice
      const sortedWords = [...words].sort((a, b) => {
        // First, prioritize by status
        const statusOrder = { new: 0, learning: 1, reviewing: 2, mastered: 3 };
        const statusDiff = statusOrder[a.progress.status] - statusOrder[b.progress.status];
        
        if (statusDiff !== 0) return statusDiff;
        
        // Then by strength
        return a.progress.strength - b.progress.strength;
      });
      
      // Take the first 10 words or all if less than 10
      setLearningWords(sortedWords.slice(0, Math.min(10, sortedWords.length)));
    }
  }, [words]);
  
  // Set up exercise when current word changes
  useEffect(() => {
    if (learningWords.length > 0) {
      setupExercise();
    }
  }, [currentIndex, exerciseType, learningWords]);
  
  const setupExercise = () => {
    const currentWord = learningWords[currentIndex];
    
    // Reset states
    setIsFlipped(false);
    setUserAnswer('');
    setShowHint(false);
    setSelectedOption(null);
    flipAnim.setValue(0);
    
    if (exerciseType === 'multipleChoice') {
      generateMultipleChoiceOptions(currentWord);
    } else if (exerciseType === 'matching') {
      generateMatchingPairs();
    }
  };
  
  const generateMultipleChoiceOptions = (currentWord: Word) => {
    const correctAnswer = currentWord.translation;
    const options = [correctAnswer];
    
    // Get 3 random incorrect options
    const otherWords = words
      .filter(word => word.translation !== correctAnswer)
      .map(word => word.translation);
    
    // If we don't have enough words, duplicate some options
    if (otherWords.length < 3) {
      while (options.length < 4) {
        options.push(`Option ${options.length + 1}`);
      }
    } else {
      // Shuffle and take 3
      const shuffled = [...otherWords].sort(() => 0.5 - Math.random());
      options.push(...shuffled.slice(0, 3));
    }
    
    // Shuffle the options
    setOptions(options.sort(() => 0.5 - Math.random()));
  };
  
  const generateMatchingPairs = () => {
    // Create pairs from current and nearby words
    const startIdx = Math.max(0, currentIndex - 2);
    const endIdx = Math.min(learningWords.length - 1, currentIndex + 2);
    const wordsToUse = learningWords.slice(startIdx, endIdx + 1);
    
    // Create pairs (original + translation)
    const pairs: {id: string, text: string, matched: boolean, selected: boolean}[] = [];
    
    wordsToUse.forEach(word => {
      pairs.push({
        id: `original_${word.id}`,
        text: word.original,
        matched: false,
        selected: false
      });
      
      pairs.push({
        id: `translation_${word.id}`,
        text: word.translation,
        matched: false,
        selected: false
      });
    });
    
    // Shuffle the pairs
    setMatchingPairs(pairs.sort(() => 0.5 - Math.random()));
  };
  
  const flipCard = () => {
    setIsFlipped(!isFlipped);
    Animated.timing(flipAnim, {
      toValue: isFlipped ? 0 : 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };
  
  const frontInterpolate = flipAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'],
  });
  
  const backInterpolate = flipAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['180deg', '360deg'],
  });
  
  const frontAnimatedStyle = {
    transform: [{ rotateY: frontInterpolate }],
  };
  
  const backAnimatedStyle = {
    transform: [{ rotateY: backInterpolate }],
  };
  
  const handleNext = () => {
    if (currentIndex < learningWords.length - 1) {
      // Reset card to front side before moving to next card
      if (isFlipped) {
        setIsFlipped(false);
        Animated.timing(flipAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }).start();
      }
      
      setCurrentIndex(currentIndex + 1);
      
      // Randomly change exercise type for variety
      if (Math.random() > 0.7) {
        const types: ExerciseType[] = ['flashcard', 'typing', 'multipleChoice', 'matching'];
        const newType = types[Math.floor(Math.random() * types.length)];
        setExerciseType(newType);
      }
    } else {
      setCompleted(true);
    }
  };
  
  const handlePrevious = () => {
    if (currentIndex > 0) {
      // Reset card to front side before moving to previous card
      if (isFlipped) {
        setIsFlipped(false);
        Animated.timing(flipAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }).start();
      }
      
      setCurrentIndex(currentIndex - 1);
    }
  };
  
  const handleKnow = () => {
    const wordId = learningWords[currentIndex].id;
    updateWordProgress(id, wordId, true);
    
    setResults([...results, { wordId, correct: true }]);
    handleNext();
  };
  
  const handleDontKnow = () => {
    const wordId = learningWords[currentIndex].id;
    updateWordProgress(id, wordId, false);
    
    setResults([...results, { wordId, correct: false }]);
    handleNext();
  };
  
  const handleFinish = () => {
    Alert.alert(
      'Learning Complete',
      `You've completed this learning session. Would you like to review these words again?`,
      [
        {
          text: 'Review Again',
          onPress: () => {
            setCurrentIndex(0);
            setCompleted(false);
            setResults([]);
          },
        },
        {
          text: 'Finish',
          onPress: () => router.back(),
        },
      ]
    );
  };
  
  const handleChangeExerciseType = () => {
    const types: ExerciseType[] = ['flashcard', 'typing', 'multipleChoice', 'matching'];
    const currentIndex = types.indexOf(exerciseType);
    const nextIndex = (currentIndex + 1) % types.length;
    setExerciseType(types[nextIndex]);
  };
  
  const checkTypingAnswer = () => {
    const currentWord = learningWords[currentIndex];
    const isCorrect = userAnswer.toLowerCase().trim() === currentWord.translation.toLowerCase().trim();
    
    const wordId = currentWord.id;
    updateWordProgress(id, wordId, isCorrect);
    
    setResults([...results, { wordId, correct: isCorrect }]);
    
    if (isCorrect) {
      Alert.alert('Correct!', 'Great job!', [
        { text: 'Next', onPress: handleNext }
      ]);
    } else {
      Alert.alert('Incorrect', `The correct answer is: ${currentWord.translation}`, [
        { text: 'Next', onPress: handleNext }
      ]);
    }
  };
  
  const checkMultipleChoiceAnswer = (selected: string) => {
    const currentWord = learningWords[currentIndex];
    const isCorrect = selected === currentWord.translation;
    
    setSelectedOption(selected);
    
    const wordId = currentWord.id;
    updateWordProgress(id, wordId, isCorrect);
    
    setResults([...results, { wordId, correct: isCorrect }]);
    
    setTimeout(() => {
      handleNext();
    }, 1000);
  };
  
  const handleMatchingPairSelect = (pairId: string) => {
    // Update the selected state
    const updatedPairs = matchingPairs.map(pair => {
      if (pair.id === pairId) {
        return { ...pair, selected: !pair.selected };
      }
      return pair;
    });
    
    // Find the selected pair
    const selectedPair = updatedPairs.find(pair => pair.id === pairId);
    
    if (!selectedPair) return;
    
    // If this is the first selection
    if (firstSelected === null) {
      setFirstSelected(pairId);
      setMatchingPairs(updatedPairs);
      return;
    }
    
    // If this is the second selection
    const firstPair = updatedPairs.find(pair => pair.id === firstSelected);
    
    if (!firstPair) return;
    
    // Check if they match (one is original, one is translation of the same word)
    const firstWordId = firstPair.id.split('_')[1];
    const secondWordId = selectedPair.id.split('_')[1];
    
    const isMatch = firstWordId === secondWordId && 
                   firstPair.id.split('_')[0] !== selectedPair.id.split('_')[0];
    
    // Update the pairs
    const finalPairs = updatedPairs.map(pair => {
      if (pair.id === firstSelected || pair.id === pairId) {
        return { 
          ...pair, 
          matched: isMatch,
          selected: false 
        };
      }
      return pair;
    });
    
    setMatchingPairs(finalPairs);
    setFirstSelected(null);
    
    // Check if all pairs are matched
    const allMatched = finalPairs.every(pair => pair.matched);
    
    if (allMatched) {
      // Update word progress
      const wordId = learningWords[currentIndex].id;
      updateWordProgress(id, wordId, true);
      
      setResults([...results, { wordId, correct: true }]);
      
      setTimeout(() => {
        handleNext();
      }, 500);
    }
  };
  
  if (!list || learningWords.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>No Words to Learn</Text>
          <Text style={styles.emptyDescription}>
            This list doesn't have any words yet. Add some words to start learning.
          </Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            style={styles.emptyButton}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  if (completed) {
    const correctCount = results.filter(r => r.correct).length;
    const totalCount = results.length;
    const percentage = Math.round((correctCount / totalCount) * 100);
    
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <Stack.Screen options={{ title: 'Learning Complete' }} />
        
        <View style={styles.completedContainer}>
          <View style={styles.resultCard}>
            <Text style={styles.resultTitle}>Great job!</Text>
            
            <View style={styles.resultStats}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{totalCount}</Text>
                <Text style={styles.statLabel}>Words</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{correctCount}</Text>
                <Text style={styles.statLabel}>Correct</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{percentage}%</Text>
                <Text style={styles.statLabel}>Score</Text>
              </View>
            </View>
            
            <Text style={styles.resultMessage}>
              {percentage >= 80 
                ? "Excellent! You're making great progress." 
                : percentage >= 50 
                  ? "Good job! Keep practicing to improve." 
                  : "Keep practicing! You'll get better with time."}
            </Text>
          </View>
          
          <View style={styles.completedActions}>
            <Button
              title="Practice Again"
              onPress={() => {
                setCurrentIndex(0);
                setCompleted(false);
                setResults([]);
              }}
              leftIcon={<RotateCcw size={20} color="white" />}
              style={styles.actionButton}
            />
            
            <Button
              title="Take a Quiz"
              onPress={() => router.push(`/quiz/${id}`)}
              variant="secondary"
              style={styles.actionButton}
            />
            
            <Button
              title="Finish"
              onPress={() => router.back()}
              variant="outline"
              style={styles.actionButton}
            />
          </View>
        </View>
      </SafeAreaView>
    );
  }
  
  const currentWord = learningWords[currentIndex];
  
  const renderExercise = () => {
    switch (exerciseType) {
      case 'flashcard':
        return (
          <TouchableOpacity 
            activeOpacity={0.9}
            onPress={flipCard}
            style={styles.cardWrapper}
          >
            <Animated.View style={[styles.card, frontAnimatedStyle, styles.cardFront]}>
              <Text style={styles.cardTitle}>
                {isFlipped ? currentWord.translation : currentWord.original}
              </Text>
              
              {currentWord.pronunciation && !isFlipped && (
                <Text style={styles.pronunciation}>
                  /{currentWord.pronunciation}/
                </Text>
              )}
              
              <TouchableOpacity style={styles.soundButton}>
                <Volume2 size={24} color={colors.primary} />
              </TouchableOpacity>
              
              <Text style={styles.flipPrompt}>Tap to flip</Text>
            </Animated.View>
            
            <Animated.View style={[styles.card, backAnimatedStyle, styles.cardBack]}>
              <Text style={styles.cardTitle}>
                {isFlipped ? currentWord.original : currentWord.translation}
              </Text>
              
              {currentWord.pronunciation && isFlipped && (
                <Text style={styles.pronunciation}>
                  /{currentWord.pronunciation}/
                </Text>
              )}
              
              {currentWord.example && (
                <Text style={styles.example}>{currentWord.example}</Text>
              )}
              
              <TouchableOpacity style={styles.soundButton}>
                <Volume2 size={24} color={colors.primary} />
              </TouchableOpacity>
              
              <Text style={styles.flipPrompt}>Tap to flip</Text>
            </Animated.View>
          </TouchableOpacity>
        );
        
      case 'typing':
        return (
          <View style={styles.typingContainer}>
            <Card style={styles.typingCard}>
              <Text style={styles.typingPrompt}>
                Translate this word:
              </Text>
              
              <Text style={styles.typingWord}>{currentWord.original}</Text>
              
              {currentWord.pronunciation && (
                <Text style={styles.pronunciation}>
                  /{currentWord.pronunciation}/
                </Text>
              )}
              
              <TextInput
                style={styles.typingInput}
                value={userAnswer}
                onChangeText={setUserAnswer}
                placeholder="Type your answer..."
                autoCapitalize="none"
                autoCorrect={false}
              />
              
              <View style={styles.typingActions}>
                <Button
                  title="Check Answer"
                  onPress={checkTypingAnswer}
                  style={styles.typingButton}
                />
                
                <TouchableOpacity 
                  style={styles.hintButton}
                  onPress={() => setShowHint(!showHint)}
                >
                  <HelpCircle size={20} color={colors.primary} />
                  <Text style={styles.hintText}>Hint</Text>
                </TouchableOpacity>
              </View>
              
              {showHint && (
                <View style={styles.hintContainer}>
                  <Text style={styles.hintTitle}>Hint:</Text>
                  <Text style={styles.hintContent}>
                    {currentWord.translation.charAt(0)}
                    {currentWord.translation.slice(1).replace(/./g, '_ ')}
                  </Text>
                </View>
              )}
            </Card>
          </View>
        );
        
      case 'multipleChoice':
        return (
          <View style={styles.multipleChoiceContainer}>
            <Card style={styles.multipleChoiceCard}>
              <Text style={styles.multipleChoicePrompt}>
                Choose the correct translation:
              </Text>
              
              <Text style={styles.multipleChoiceWord}>{currentWord.original}</Text>
              
              {currentWord.pronunciation && (
                <Text style={styles.pronunciation}>
                  /{currentWord.pronunciation}/
                </Text>
              )}
              
              <View style={styles.optionsContainer}>
                {options.map((option, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.optionButton,
                      selectedOption === option && styles.selectedOption,
                      selectedOption === option && 
                        option === currentWord.translation && 
                        styles.correctOption,
                      selectedOption === option && 
                        option !== currentWord.translation && 
                        styles.incorrectOption,
                    ]}
                    onPress={() => checkMultipleChoiceAnswer(option)}
                    disabled={selectedOption !== null}
                  >
                    <Text 
                      style={[
                        styles.optionText,
                        selectedOption === option && 
                          option === currentWord.translation && 
                          styles.correctOptionText,
                        selectedOption === option && 
                          option !== currentWord.translation && 
                          styles.incorrectOptionText,
                      ]}
                    >
                      {option}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </Card>
          </View>
        );
        
      case 'matching':
        return (
          <View style={styles.matchingContainer}>
            <Card style={styles.matchingCard}>
              <Text style={styles.matchingPrompt}>
                Match the words with their translations:
              </Text>
              
              <View style={styles.matchingPairsContainer}>
                {matchingPairs.map((pair) => (
                  <TouchableOpacity
                    key={pair.id}
                    style={[
                      styles.matchingPair,
                      pair.matched && styles.matchedPair,
                      pair.selected && styles.selectedPair,
                    ]}
                    onPress={() => handleMatchingPairSelect(pair.id)}
                    disabled={pair.matched}
                  >
                    <Text 
                      style={[
                        styles.matchingPairText,
                        pair.matched && styles.matchedPairText,
                      ]}
                    >
                      {pair.text}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </Card>
          </View>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: 'Learning Mode',
          headerRight: () => (
            <TouchableOpacity 
              onPress={handleFinish}
              style={styles.headerButton}
            >
              <Text style={styles.headerButtonText}>Finish</Text>
            </TouchableOpacity>
          ),
        }} 
      />
      
      <View style={styles.progressContainer}>
        <Text style={styles.progressText}>
          {currentIndex + 1} of {learningWords.length}
        </Text>
        <View style={styles.progressBar}>
          <View 
            style={[
              styles.progressFill, 
              { 
                width: `${((currentIndex + 1) / learningWords.length) * 100}%` 
              }
            ]} 
          />
        </View>
      </View>
      
      <View style={styles.exerciseTypeContainer}>
        <TouchableOpacity 
          style={styles.exerciseTypeButton}
          onPress={handleChangeExerciseType}
        >
          {exerciseType === 'flashcard' && (
            <>
              <BookOpen size={16} color={colors.primary} />
              <Text style={styles.exerciseTypeText}>Flashcard</Text>
            </>
          )}
          
          {exerciseType === 'typing' && (
            <>
              <Keyboard size={16} color={colors.primary} />
              <Text style={styles.exerciseTypeText}>Typing</Text>
            </>
          )}
          
          {exerciseType === 'multipleChoice' && (
            <>
              <ListChecks size={16} color={colors.primary} />
              <Text style={styles.exerciseTypeText}>Multiple Choice</Text>
            </>
          )}
          
          {exerciseType === 'matching' && (
            <>
              <Shuffle size={16} color={colors.primary} />
              <Text style={styles.exerciseTypeText}>Matching</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
      
      <View style={styles.cardContainer}>
        {renderExercise()}
      </View>
      
      {exerciseType === 'flashcard' && (
        <>
          <View style={styles.navigationContainer}>
            <TouchableOpacity 
              style={[styles.navButton, currentIndex === 0 && styles.disabledButton]}
              onPress={handlePrevious}
              disabled={currentIndex === 0}
            >
              <ArrowLeft 
                size={24} 
                color={currentIndex === 0 ? colors.textSecondary : colors.text} 
              />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.navButton, styles.nextButton]}
              onPress={handleNext}
            >
              <ArrowRight size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.actionsContainer}>
            <Button
              title="I Don't Know"
              onPress={handleDontKnow}
              variant="outline"
              leftIcon={<X size={20} color={colors.error} />}
              style={[styles.actionButton, styles.dontKnowButton]}
              textStyle={{ color: colors.error }}
            />
            
            <Button
              title="I Know"
              onPress={handleKnow}
              leftIcon={<Check size={20} color="white" />}
              style={styles.actionButton}
            />
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  headerButtonText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  progressText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
    textAlign: 'center',
  },
  progressBar: {
    height: 6,
    backgroundColor: '#e9ecef',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  exerciseTypeContainer: {
    alignItems: 'center',
    marginBottom: 8,
  },
  exerciseTypeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
  },
  exerciseTypeText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  cardWrapper: {
    width: width - 48,
    height: 300,
    perspective: 1000,
  },
  card: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    backfaceVisibility: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cardFront: {
    backgroundColor: 'white',
  },
  cardBack: {
    backgroundColor: 'white',
    transform: [{ rotateY: '180deg' }],
  },
  cardTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 16,
  },
  pronunciation: {
    fontSize: 18,
    color: colors.textSecondary,
    fontStyle: 'italic',
    marginBottom: 16,
    textAlign: 'center',
  },
  example: {
    fontSize: 16,
    color: colors.text,
    fontStyle: 'italic',
    textAlign: 'center',
    marginVertical: 16,
    lineHeight: 24,
  },
  soundButton: {
    padding: 12,
    marginTop: 16,
  },
  flipPrompt: {
    position: 'absolute',
    bottom: 16,
    fontSize: 14,
    color: colors.textSecondary,
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  navButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  nextButton: {
    backgroundColor: 'white',
  },
  disabledButton: {
    opacity: 0.5,
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    gap: 16,
  },
  actionButton: {
    flex: 1,
  },
  dontKnowButton: {
    borderColor: colors.error,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  emptyButton: {
    minWidth: 150,
  },
  completedContainer: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  resultCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  resultTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 24,
  },
  resultStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 24,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  resultMessage: {
    fontSize: 16,
    color: colors.text,
    textAlign: 'center',
    lineHeight: 24,
  },
  completedActions: {
    gap: 12,
  },
  // Typing exercise styles
  typingContainer: {
    width: '100%',
  },
  typingCard: {
    padding: 24,
  },
  typingPrompt: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 16,
  },
  typingWord: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 8,
  },
  typingInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  typingActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  typingButton: {
    flex: 1,
    marginRight: 12,
  },
  hintButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    gap: 4,
  },
  hintText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  hintContainer: {
    marginTop: 16,
    padding: 12,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 8,
  },
  hintTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
    marginBottom: 4,
  },
  hintContent: {
    fontSize: 16,
    color: colors.text,
  },
  // Multiple choice styles
  multipleChoiceContainer: {
    width: '100%',
  },
  multipleChoiceCard: {
    padding: 24,
  },
  multipleChoicePrompt: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 16,
  },
  multipleChoiceWord: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 8,
  },
  optionsContainer: {
    marginTop: 16,
    gap: 12,
  },
  optionButton: {
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
  },
  selectedOption: {
    borderWidth: 2,
  },
  correctOption: {
    borderColor: colors.success,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
  },
  incorrectOption: {
    borderColor: colors.error,
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
  },
  optionText: {
    fontSize: 16,
    color: colors.text,
  },
  correctOptionText: {
    color: colors.success,
    fontWeight: '600',
  },
  incorrectOptionText: {
    color: colors.error,
    fontWeight: '600',
  },
  // Matching exercise styles
  matchingContainer: {
    width: '100%',
  },
  matchingCard: {
    padding: 24,
  },
  matchingPrompt: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 16,
  },
  matchingPairsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  matchingPair: {
    width: '48%',
    padding: 12,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 60,
  },
  matchedPair: {
    borderColor: colors.success,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
  },
  selectedPair: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
  },
  matchingPairText: {
    fontSize: 14,
    color: colors.text,
    textAlign: 'center',
  },
  matchedPairText: {
    color: colors.success,
    fontWeight: '600',
  },
});