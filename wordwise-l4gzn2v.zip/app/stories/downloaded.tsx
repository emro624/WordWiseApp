import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  SafeAreaView,
  Alert,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StoryCard } from '@/components/StoryCard';
import { EmptyState } from '@/components/EmptyState';
import { colors } from '@/constants/colors';
import { useStoryStore } from '@/store/storyStore';
import { 
  Download,
  Trash2,
} from 'lucide-react-native';

export default function DownloadedStoriesScreen() {
  const router = useRouter();
  const { 
    getDownloadedStories, 
    isStoryRead, 
    isStoryBookmarked, 
    removeDownload 
  } = useStoryStore(state => ({
    getDownloadedStories: state.getDownloadedStories,
    isStoryRead: state.isStoryRead,
    isStoryBookmarked: state.isStoryBookmarked,
    removeDownload: state.removeDownload,
  }));
  
  const downloadedStories = getDownloadedStories();
  
  const handleStoryPress = (storyId: string) => {
    router.push(`/story/${storyId}`);
  };
  
  const handleRemoveDownload = (storyId: string) => {
    Alert.alert(
      "Remove Download",
      "Are you sure you want to remove this downloaded story?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Remove", 
          onPress: () => removeDownload(storyId),
          style: "destructive"
        }
      ]
    );
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen options={{ title: 'Downloaded Stories' }} />
      
      {downloadedStories.length === 0 ? (
        <EmptyState
          title="No Downloaded Stories"
          description="You haven't downloaded any stories yet. Downloaded stories are available offline."
          icon={<Download size={64} color={colors.textSecondary} />}
          actionLabel="Browse Stories"
          onAction={() => router.push('/stories')}
        />
      ) : (
        <FlatList
          data={downloadedStories}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <View style={styles.storyItem}>
              <StoryCard
                story={item}
                isRead={isStoryRead(item.id)}
                isBookmarked={isStoryBookmarked(item.id)}
                isDownloaded={true}
                onPress={() => handleStoryPress(item.id)}
              />
              <TouchableOpacity 
                style={styles.removeButton}
                onPress={() => handleRemoveDownload(item.id)}
              >
                <Trash2 size={20} color={colors.error} />
              </TouchableOpacity>
            </View>
          )}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  listContent: {
    padding: 16,
  },
  storyItem: {
    position: 'relative',
  },
  removeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
});