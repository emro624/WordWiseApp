import React, { useState, useEffect, useMemo } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  Alert,
  TextInput,
  Image,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';
import { Word, QuizResult } from '@/types';
import { 
  Clock, 
  CheckCircle, 
  XCircle,
  ArrowRight,
  RotateCcw,
  Brain,
  Shuffle,
  Volume2,
  HelpCircle,
  AlertCircle,
} from 'lucide-react-native';

// Quiz types
type QuizType = 'multipleChoice' | 'trueFalse' | 'fillInBlank' | 'spelling';

export default function QuizScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  const { list, words, addQuizResult } = useWordListsStore(state => ({
    list: state.getList(id),
    words: state.getWords(id),
    addQuizResult: state.addQuizResult,
  }));
  
  const [quizWords, setQuizWords] = useState<Word[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [userInput, setUserInput] = useState('');
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [startTime, setStartTime] = useState<number>(0);
  const [endTime, setEndTime] = useState<number>(0);
  const [results, setResults] = useState<{ wordId: string; correct: boolean; userAnswer: string }[]>([]);
  const [quizType, setQuizType] = useState<QuizType>('multipleChoice');
  const [options, setOptions] = useState<string[]>([]);
  const [trueFalseStatement, setTrueFalseStatement] = useState<{statement: string, isTrue: boolean}>({statement: '', isTrue: false});
  const [showHint, setShowHint] = useState(false);
  
  useEffect(() => {
    if (words.length > 0) {
      // Prioritize words that need more practice
      const sortedWords = [...words].sort((a, b) => {
        // First, prioritize by status
        const statusOrder = { new: 0, learning: 1, reviewing: 2, mastered: 3 };
        const statusDiff = statusOrder[a.progress.status] - statusOrder[b.progress.status];
        
        if (statusDiff !== 0) return statusDiff;
        
        // Then by strength
        return a.progress.strength - b.progress.strength;
      });
      
      // Take the first 10 words or all if less than 10
      setQuizWords(sortedWords.slice(0, Math.min(10, sortedWords.length)));
    }
  }, [words]);
  
  // Set up quiz question when current word changes
  useEffect(() => {
    if (quizStarted && quizWords.length > 0) {
      setupQuestion();
    }
  }, [currentIndex, quizType, quizStarted, quizWords]);
  
  const setupQuestion = () => {
    const currentWord = quizWords[currentIndex];
    
    // Reset states
    setSelectedAnswer(null);
    setUserInput('');
    setIsCorrect(null);
    setShowHint(false);
    
    // Randomly select quiz type for variety
    if (currentIndex % 3 === 0) {
      const types: QuizType[] = ['multipleChoice', 'trueFalse', 'fillInBlank', 'spelling'];
      const newType = types[Math.floor(Math.random() * types.length)];
      setQuizType(newType);
    }
    
    if (quizType === 'multipleChoice') {
      generateMultipleChoiceOptions(currentWord);
    } else if (quizType === 'trueFalse') {
      generateTrueFalseStatement(currentWord);
    }
  };
  
  const generateMultipleChoiceOptions = (currentWord: Word) => {
    const correctAnswer = currentWord.translation;
    const options = [correctAnswer];
    
    // Get 3 random incorrect options
    const otherWords = words
      .filter(word => word.translation !== correctAnswer)
      .map(word => word.translation);
    
    // If we don't have enough words, duplicate some options
    if (otherWords.length < 3) {
      while (options.length < 4) {
        options.push(`Option ${options.length + 1}`);
      }
    } else {
      // Shuffle and take 3
      const shuffled = [...otherWords].sort(() => 0.5 - Math.random());
      options.push(...shuffled.slice(0, 3));
    }
    
    // Shuffle the options
    setOptions(options.sort(() => 0.5 - Math.random()));
  };
  
  const generateTrueFalseStatement = (currentWord: Word) => {
    // 50% chance of true statement
    const isTrue = Math.random() > 0.5;
    
    if (isTrue) {
      setTrueFalseStatement({
        statement: `"${currentWord.original}" means "${currentWord.translation}"`,
        isTrue: true
      });
    } else {
      // Get a random incorrect translation
      const incorrectTranslations = words
        .filter(word => word.id !== currentWord.id)
        .map(word => word.translation);
      
      if (incorrectTranslations.length > 0) {
        const randomIncorrect = incorrectTranslations[Math.floor(Math.random() * incorrectTranslations.length)];
        setTrueFalseStatement({
          statement: `"${currentWord.original}" means "${randomIncorrect}"`,
          isTrue: false
        });
      } else {
        // Fallback if no other words available
        setTrueFalseStatement({
          statement: `"${currentWord.original}" means "something else"`,
          isTrue: false
        });
      }
    }
  };
  
  const startQuiz = () => {
    setQuizStarted(true);
    setStartTime(Date.now());
  };
  
  const handleSelectMultipleChoice = (answer: string) => {
    if (selectedAnswer !== null) return; // Already answered
    
    const currentWord = quizWords[currentIndex];
    const isAnswerCorrect = answer === currentWord.translation;
    
    setSelectedAnswer(answer);
    setIsCorrect(isAnswerCorrect);
    
    // Add to results
    setResults([
      ...results,
      { wordId: currentWord.id, correct: isAnswerCorrect, userAnswer: answer },
    ]);
  };
  
  const handleTrueFalseAnswer = (answer: boolean) => {
    if (selectedAnswer !== null) return; // Already answered
    
    const isAnswerCorrect = answer === trueFalseStatement.isTrue;
    
    setSelectedAnswer(answer ? 'true' : 'false');
    setIsCorrect(isAnswerCorrect);
    
    // Add to results
    const currentWord = quizWords[currentIndex];
    setResults([
      ...results,
      { 
        wordId: currentWord.id, 
        correct: isAnswerCorrect, 
        userAnswer: answer ? 'True' : 'False' 
      },
    ]);
  };
  
  const handleFillInBlankSubmit = () => {
    const currentWord = quizWords[currentIndex];
    const isAnswerCorrect = userInput.toLowerCase().trim() === currentWord.translation.toLowerCase().trim();
    
    setIsCorrect(isAnswerCorrect);
    
    // Add to results
    setResults([
      ...results,
      { wordId: currentWord.id, correct: isAnswerCorrect, userAnswer: userInput },
    ]);
  };
  
  const handleSpellingSubmit = () => {
    const currentWord = quizWords[currentIndex];
    const isAnswerCorrect = userInput.toLowerCase().trim() === currentWord.original.toLowerCase().trim();
    
    setIsCorrect(isAnswerCorrect);
    
    // Add to results
    setResults([
      ...results,
      { wordId: currentWord.id, correct: isAnswerCorrect, userAnswer: userInput },
    ]);
  };
  
  const handleNext = () => {
    if (currentIndex < quizWords.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Quiz completed
      setEndTime(Date.now());
      setQuizCompleted(true);
      
      // Save quiz results
      const timeSpent = Math.round((Date.now() - startTime) / 1000);
      const correctAnswers = results.filter(r => r.correct).length;
      
      addQuizResult({
        listId: id,
        totalQuestions: quizWords.length,
        correctAnswers,
        timeSpent,
        words: results.map(r => ({ wordId: r.wordId, correct: r.correct })),
      });
    }
  };
  
  const handleRestartQuiz = () => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setUserInput('');
    setIsCorrect(null);
    setQuizCompleted(false);
    setResults([]);
    setStartTime(Date.now());
    setQuizType('multipleChoice');
  };
  
  const handleFinish = () => {
    router.back();
  };
  
  if (!list || quizWords.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>No Words for Quiz</Text>
          <Text style={styles.emptyDescription}>
            This list doesn't have enough words for a quiz. Add more words to start quizzing.
          </Text>
          <Button
            title="Go Back"
            onPress={() => router.back()}
            style={styles.emptyButton}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  if (!quizStarted) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <Stack.Screen options={{ title: 'Quiz Mode' }} />
        
        <View style={styles.startContainer}>
          <Card style={styles.startCard}>
            <Text style={styles.startTitle}>Ready for a Quiz?</Text>
            <Text style={styles.startDescription}>
              Test your knowledge of {list.name} with a variety of question types.
            </Text>
            
            <Image 
              source={{ uri: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=300&auto=format&fit=crop' }}
              style={styles.quizImage}
            />
            
            <View style={styles.quizInfo}>
              <View style={styles.infoItem}>
                <Text style={styles.infoValue}>{quizWords.length}</Text>
                <Text style={styles.infoLabel}>Questions</Text>
              </View>
              
              <View style={styles.infoItem}>
                <Text style={styles.infoValue}>Mixed</Text>
                <Text style={styles.infoLabel}>Quiz Types</Text>
              </View>
            </View>
          </Card>
          
          <Button
            title="Start Quiz"
            onPress={startQuiz}
            style={styles.startButton}
          />
        </View>
      </SafeAreaView>
    );
  }
  
  if (quizCompleted) {
    const correctCount = results.filter(r => r.correct).length;
    const totalCount = results.length;
    const percentage = Math.round((correctCount / totalCount) * 100);
    const timeSpent = Math.round((endTime - startTime) / 1000);
    
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar style="dark" />
        
        <Stack.Screen options={{ title: 'Quiz Results' }} />
        
        <ScrollView 
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <Card style={styles.resultCard}>
            <Text style={styles.resultTitle}>Quiz Complete!</Text>
            
            <View style={styles.resultStats}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{percentage}%</Text>
                <Text style={styles.statLabel}>Score</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{correctCount}/{totalCount}</Text>
                <Text style={styles.statLabel}>Correct</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{timeSpent}s</Text>
                <Text style={styles.statLabel}>Time</Text>
              </View>
            </View>
            
            <Text style={styles.resultMessage}>
              {percentage >= 80 
                ? "Excellent! You have a strong grasp of these words." 
                : percentage >= 50 
                  ? "Good job! Keep practicing to improve your score." 
                  : "Keep practicing! You'll get better with time."}
            </Text>
          </Card>
          
          <Text style={styles.answersTitle}>Your Answers</Text>
          
          {quizWords.map((word, index) => {
            const result = results[index];
            if (!result) return null;
            
            return (
              <Card key={word.id} style={styles.answerCard}>
                <View style={styles.answerHeader}>
                  <Text style={styles.questionNumber}>Question {index + 1}</Text>
                  {result.correct ? (
                    <CheckCircle size={20} color={colors.success} />
                  ) : (
                    <XCircle size={20} color={colors.error} />
                  )}
                </View>
                
                <Text style={styles.questionText}>{word.original}</Text>
                
                <View style={styles.answerDetails}>
                  <View style={styles.answerItem}>
                    <Text style={styles.answerLabel}>Your answer:</Text>
                    <Text 
                      style={[
                        styles.answerValue,
                        result.correct ? styles.correctAnswer : styles.incorrectAnswer,
                      ]}
                    >
                      {result.userAnswer}
                    </Text>
                  </View>
                  
                  {!result.correct && (
                    <View style={styles.answerItem}>
                      <Text style={styles.answerLabel}>Correct answer:</Text>
                      <Text style={[styles.answerValue, styles.correctAnswer]}>
                        {word.translation}
                      </Text>
                    </View>
                  )}
                </View>
              </Card>
            );
          })}
          
          <View style={styles.resultActions}>
            <Button
              title="Try Again"
              onPress={handleRestartQuiz}
              leftIcon={<RotateCcw size={20} color="white" />}
              style={styles.actionButton}
            />
            
            <Button
              title="Practice Mode"
              onPress={() => router.push(`/learning/${id}`)}
              variant="secondary"
              leftIcon={<Brain size={20} color={colors.text} />}
              style={styles.actionButton}
            />
            
            <Button
              title="Finish"
              onPress={handleFinish}
              variant="outline"
              style={styles.actionButton}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
  
  const currentWord = quizWords[currentIndex];
  
  const renderQuizContent = () => {
    switch (quizType) {
      case 'multipleChoice':
        return (
          <View style={styles.quizContainer}>
            <Card style={styles.questionCard}>
              <View style={styles.quizTypeIndicator}>
                <Shuffle size={16} color={colors.primary} />
                <Text style={styles.quizTypeText}>Multiple Choice</Text>
              </View>
              
              <Text style={styles.questionTitle}>Translate this word:</Text>
              <Text style={styles.questionWord}>{currentWord.original}</Text>
              
              {currentWord.pronunciation && (
                <Text style={styles.pronunciation}>
                  /{currentWord.pronunciation}/
                </Text>
              )}
              
              <TouchableOpacity style={styles.soundButton}>
                <Volume2 size={20} color={colors.primary} />
              </TouchableOpacity>
            </Card>
            
            <View style={styles.optionsContainer}>
              {options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={[
                    styles.optionButton,
                    selectedAnswer === option && styles.selectedOption,
                    selectedAnswer === option && isCorrect && styles.correctOption,
                    selectedAnswer === option && !isCorrect && styles.incorrectOption,
                    selectedAnswer !== null && 
                      option === currentWord.translation && 
                      styles.correctOption,
                  ]}
                  onPress={() => handleSelectMultipleChoice(option)}
                  disabled={selectedAnswer !== null}
                >
                  <Text 
                    style={[
                      styles.optionText,
                      selectedAnswer === option && isCorrect && styles.correctOptionText,
                      selectedAnswer === option && !isCorrect && styles.incorrectOptionText,
                      selectedAnswer !== null && 
                        option === currentWord.translation && 
                        styles.correctOptionText,
                    ]}
                  >
                    {option}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        );
        
      case 'trueFalse':
        return (
          <View style={styles.quizContainer}>
            <Card style={styles.questionCard}>
              <View style={styles.quizTypeIndicator}>
                <CheckCircle size={16} color={colors.primary} />
                <Text style={styles.quizTypeText}>True or False</Text>
              </View>
              
              <Text style={styles.questionTitle}>Is this statement correct?</Text>
              <Text style={styles.trueFalseStatement}>{trueFalseStatement.statement}</Text>
            </Card>
            
            <View style={styles.trueFalseContainer}>
              <TouchableOpacity
                style={[
                  styles.trueFalseButton,
                  selectedAnswer === 'true' && styles.selectedOption,
                  selectedAnswer === 'true' && isCorrect && styles.correctOption,
                  selectedAnswer === 'true' && !isCorrect && styles.incorrectOption,
                ]}
                onPress={() => handleTrueFalseAnswer(true)}
                disabled={selectedAnswer !== null}
              >
                <Text 
                  style={[
                    styles.trueFalseText,
                    selectedAnswer === 'true' && isCorrect && styles.correctOptionText,
                    selectedAnswer === 'true' && !isCorrect && styles.incorrectOptionText,
                  ]}
                >
                  True
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.trueFalseButton,
                  selectedAnswer === 'false' && styles.selectedOption,
                  selectedAnswer === 'false' && isCorrect && styles.correctOption,
                  selectedAnswer === 'false' && !isCorrect && styles.incorrectOption,
                ]}
                onPress={() => handleTrueFalseAnswer(false)}
                disabled={selectedAnswer !== null}
              >
                <Text 
                  style={[
                    styles.trueFalseText,
                    selectedAnswer === 'false' && isCorrect && styles.correctOptionText,
                    selectedAnswer === 'false' && !isCorrect && styles.incorrectOptionText,
                  ]}
                >
                  False
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        );
        
      case 'fillInBlank':
        return (
          <View style={styles.quizContainer}>
            <Card style={styles.questionCard}>
              <View style={styles.quizTypeIndicator}>
                <AlertCircle size={16} color={colors.primary} />
                <Text style={styles.quizTypeText}>Fill in the Blank</Text>
              </View>
              
              <Text style={styles.questionTitle}>Translate this word:</Text>
              <Text style={styles.questionWord}>{currentWord.original}</Text>
              
              {currentWord.pronunciation && (
                <Text style={styles.pronunciation}>
                  /{currentWord.pronunciation}/
                </Text>
              )}
              
              <TextInput
                style={styles.fillInBlankInput}
                value={userInput}
                onChangeText={setUserInput}
                placeholder="Type your answer..."
                autoCapitalize="none"
                autoCorrect={false}
                editable={isCorrect === null}
              />
              
              {isCorrect !== null && (
                <View style={[
                  styles.feedbackContainer,
                  isCorrect ? styles.correctFeedback : styles.incorrectFeedback
                ]}>
                  <Text style={styles.feedbackText}>
                    {isCorrect ? 'Correct!' : `Incorrect. The answer is "${currentWord.translation}"`}
                  </Text>
                </View>
              )}
              
              {isCorrect === null && (
                <View style={styles.fillInBlankActions}>
                  <Button
                    title="Submit"
                    onPress={handleFillInBlankSubmit}
                    style={styles.submitButton}
                  />
                  
                  <TouchableOpacity 
                    style={styles.hintButton}
                    onPress={() => setShowHint(!showHint)}
                  >
                    <HelpCircle size={20} color={colors.primary} />
                    <Text style={styles.hintText}>Hint</Text>
                  </TouchableOpacity>
                </View>
              )}
              
              {showHint && (
                <View style={styles.hintContainer}>
                  <Text style={styles.hintTitle}>Hint:</Text>
                  <Text style={styles.hintContent}>
                    {currentWord.translation.charAt(0)}
                    {currentWord.translation.slice(1).replace(/./g, '_ ')}
                  </Text>
                </View>
              )}
            </Card>
          </View>
        );
        
      case 'spelling':
        return (
          <View style={styles.quizContainer}>
            <Card style={styles.questionCard}>
              <View style={styles.quizTypeIndicator}>
                <AlertCircle size={16} color={colors.primary} />
                <Text style={styles.quizTypeText}>Spelling</Text>
              </View>
              
              <Text style={styles.questionTitle}>Spell this word:</Text>
              <Text style={styles.questionWord}>{currentWord.translation}</Text>
              
              <TextInput
                style={styles.fillInBlankInput}
                value={userInput}
                onChangeText={setUserInput}
                placeholder="Type the spelling in the original language..."
                autoCapitalize="none"
                autoCorrect={false}
                editable={isCorrect === null}
              />
              
              {isCorrect !== null && (
                <View style={[
                  styles.feedbackContainer,
                  isCorrect ? styles.correctFeedback : styles.incorrectFeedback
                ]}>
                  <Text style={styles.feedbackText}>
                    {isCorrect ? 'Correct!' : `Incorrect. The correct spelling is "${currentWord.original}"`}
                  </Text>
                </View>
              )}
              
              {isCorrect === null && (
                <View style={styles.fillInBlankActions}>
                  <Button
                    title="Submit"
                    onPress={handleSpellingSubmit}
                    style={styles.submitButton}
                  />
                  
                  <TouchableOpacity 
                    style={styles.hintButton}
                    onPress={() => setShowHint(!showHint)}
                  >
                    <HelpCircle size={20} color={colors.primary} />
                    <Text style={styles.hintText}>Hint</Text>
                  </TouchableOpacity>
                </View>
              )}
              
              {showHint && (
                <View style={styles.hintContainer}>
                  <Text style={styles.hintTitle}>Hint:</Text>
                  <Text style={styles.hintContent}>
                    {currentWord.original.charAt(0)}
                    {currentWord.original.slice(1).replace(/./g, '_ ')}
                  </Text>
                </View>
              )}
            </Card>
          </View>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: 'Quiz Mode',
          headerRight: () => (
            <TouchableOpacity 
              onPress={() => {
                Alert.alert(
                  'Quit Quiz',
                  'Are you sure you want to quit? Your progress will be lost.',
                  [
                    {
                      text: 'Cancel',
                      style: 'cancel',
                    },
                    {
                      text: 'Quit',
                      onPress: () => router.back(),
                      style: 'destructive',
                    },
                  ]
                );
              }}
              style={styles.headerButton}
            >
              <Text style={styles.headerButtonText}>Quit</Text>
            </TouchableOpacity>
          ),
        }} 
      />
      
      <View style={styles.progressContainer}>
        <Text style={styles.progressText}>
          Question {currentIndex + 1} of {quizWords.length}
        </Text>
        <View style={styles.progressBar}>
          <View 
            style={[
              styles.progressFill, 
              { 
                width: `${((currentIndex + 1) / quizWords.length) * 100}%` 
              }
            ]} 
          />
        </View>
      </View>
      
      {renderQuizContent()}
      
      <View style={styles.bottomContainer}>
        {(selectedAnswer !== null || isCorrect !== null) && (
          <Button
            title={currentIndex < quizWords.length - 1 ? 'Next Question' : 'Finish Quiz'}
            onPress={handleNext}
            rightIcon={<ArrowRight size={20} color="white" />}
            style={styles.nextButton}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  headerButtonText: {
    color: colors.error,
    fontSize: 16,
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 16,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  emptyButton: {
    minWidth: 150,
  },
  startContainer: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  startCard: {
    marginBottom: 24,
  },
  startTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 12,
  },
  startDescription: {
    fontSize: 16,
    color: colors.text,
    marginBottom: 24,
    lineHeight: 24,
  },
  quizImage: {
    width: '100%',
    height: 150,
    borderRadius: 8,
    marginBottom: 24,
  },
  quizInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  infoItem: {
    flex: 1,
  },
  infoValue: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.primary,
    marginBottom: 4,
  },
  infoLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  startButton: {
    marginBottom: 16,
  },
  progressContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  progressText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 8,
    textAlign: 'center',
  },
  progressBar: {
    height: 6,
    backgroundColor: '#e9ecef',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  quizContainer: {
    flex: 1,
    padding: 16,
  },
  questionCard: {
    marginBottom: 24,
    position: 'relative',
  },
  quizTypeIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginBottom: 16,
    gap: 4,
  },
  quizTypeText: {
    fontSize: 12,
    color: colors.primary,
    fontWeight: '500',
  },
  questionTitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginBottom: 12,
  },
  questionWord: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  pronunciation: {
    fontSize: 16,
    color: colors.textSecondary,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  soundButton: {
    alignSelf: 'center',
    padding: 12,
    marginTop: 8,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
  },
  selectedOption: {
    borderWidth: 2,
  },
  correctOption: {
    borderColor: colors.success,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
  },
  incorrectOption: {
    borderColor: colors.error,
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
  },
  optionText: {
    fontSize: 16,
    color: colors.text,
  },
  correctOptionText: {
    color: colors.success,
    fontWeight: '600',
  },
  incorrectOptionText: {
    color: colors.error,
    fontWeight: '600',
  },
  bottomContainer: {
    padding: 16,
  },
  nextButton: {
    marginBottom: 16,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  resultCard: {
    marginBottom: 24,
  },
  resultTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 24,
  },
  resultStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 24,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  resultMessage: {
    fontSize: 16,
    color: colors.text,
    textAlign: 'center',
    lineHeight: 24,
  },
  answersTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  answerCard: {
    marginBottom: 12,
  },
  answerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  questionNumber: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  questionText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  answerDetails: {
    gap: 8,
  },
  answerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  answerLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginRight: 8,
  },
  answerValue: {
    fontSize: 14,
    fontWeight: '500',
  },
  correctAnswer: {
    color: colors.success,
  },
  incorrectAnswer: {
    color: colors.error,
  },
  resultActions: {
    marginTop: 24,
    marginBottom: 24,
    gap: 12,
  },
  actionButton: {
    width: '100%',
  },
  // True/False styles
  trueFalseStatement: {
    fontSize: 20,
    color: colors.text,
    textAlign: 'center',
    lineHeight: 28,
    marginVertical: 16,
    fontWeight: '500',
  },
  trueFalseContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 16,
  },
  trueFalseButton: {
    flex: 1,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: 'white',
    alignItems: 'center',
  },
  trueFalseText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  // Fill in the blank styles
  fillInBlankInput: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginTop: 16,
    backgroundColor: 'white',
  },
  fillInBlankActions: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
  },
  submitButton: {
    flex: 1,
    marginRight: 12,
  },
  hintButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    gap: 4,
  },
  hintText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  hintContainer: {
    marginTop: 16,
    padding: 12,
    backgroundColor: 'rgba(93, 105, 227, 0.1)',
    borderRadius: 8,
  },
  hintTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
    marginBottom: 4,
  },
  hintContent: {
    fontSize: 16,
    color: colors.text,
  },
  feedbackContainer: {
    marginTop: 16,
    padding: 12,
    borderRadius: 8,
  },
  correctFeedback: {
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
  },
  incorrectFeedback: {
    backgroundColor: 'rgba(244, 67, 54, 0.1)',
  },
  feedbackText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    textAlign: 'center',
  },
});