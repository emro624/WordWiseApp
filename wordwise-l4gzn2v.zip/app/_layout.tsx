import React, { useEffect } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useUserStore } from '@/store/userStore';
import { colors } from '@/constants/colors';
import ErrorBoundary from './error-boundary';

export default function RootLayout() {
  const router = useRouter();
  const segments = useSegments();
  // Use individual selector to prevent infinite loops
  const isAuthenticated = useUserStore(state => state.isAuthenticated);
  
  useEffect(() => {
    // Check if the component is mounted
    const isAppReady = true;
    
    if (isAppReady) {
      // Only run navigation logic after the component is mounted
      const inAuthGroup = segments[0] === '(auth)';
      
      if (!isAuthenticated && !inAuthGroup && segments[0] !== 'reset-password') {
        // Redirect to the login page if the user is not authenticated
        // and trying to access protected screens
        router.replace('/(auth)');
      } else if (isAuthenticated && inAuthGroup) {
        // Redirect to the home page if the user is authenticated
        // and trying to access auth screens
        router.replace('/(tabs)');
      }
    }
  }, [isAuthenticated, segments, router]);
  
  return (
    <ErrorBoundary>
      <SafeAreaProvider>
        <StatusBar style="dark" />
        <Stack
          screenOptions={{
            headerStyle: {
              backgroundColor: colors.background,
            },
            headerTintColor: colors.text,
            headerTitleStyle: {
              fontWeight: '600',
            },
            contentStyle: {
              backgroundColor: colors.background,
            },
          }}
        >
          <Stack.Screen
            name="(auth)"
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="(tabs)"
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="reset-password"
            options={{ 
              title: 'Reset Password',
              headerShown: false,
            }}
          />
          <Stack.Screen
            name="list/[id]"
            options={{ 
              title: 'List Details',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="list/create"
            options={{ 
              title: 'Create List',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="list/edit/[id]"
            options={{ 
              title: 'Edit List',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="word/create"
            options={{ 
              title: 'Add Word',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="word/edit/[id]"
            options={{ 
              title: 'Edit Word',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="learning/[id]"
            options={{ 
              title: 'Learning Mode',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="quiz/[id]"
            options={{ 
              title: 'Quiz Mode',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="story/[id]"
            options={{ 
              title: 'Story',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="reminder/create"
            options={{ 
              title: 'Create Reminder',
              animation: 'slide_from_right',
            }}
          />
          <Stack.Screen
            name="reminder/edit/[id]"
            options={{ 
              title: 'Edit Reminder',
              animation: 'slide_from_right',
            }}
          />
        </Stack>
      </SafeAreaProvider>
    </ErrorBoundary>
  );
}