import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity,
  Alert,
  SafeAreaView,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { WordCard } from '@/components/WordCard';
import { EmptyState } from '@/components/EmptyState';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';
import { getLanguageFlag, getLanguageName } from '@/mocks/languages';
import { 
  Plus, 
  BookOpen, 
  Play, 
  Brain,
  Edit,
  Trash2,
  MoreVertical,
} from 'lucide-react-native';

export default function ListDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  
  const { list, words, deleteList, deleteWord } = useWordListsStore(state => ({
    list: state.getList(id),
    words: state.getWords(id),
    deleteList: state.deleteList,
    deleteWord: state.deleteWord,
  }));
  
  const [showOptions, setShowOptions] = useState(false);
  
  if (!list) {
    return (
      <EmptyState
        title="List Not Found"
        description="The word list you're looking for doesn't exist"
        actionLabel="Go Back"
        onAction={() => router.back()}
      />
    );
  }
  
  const handleAddWord = () => {
    router.push({
      pathname: '/word/create',
      params: { listId: id },
    });
  };
  
  const handleEditWord = (wordId: string) => {
    router.push({
      pathname: `/word/edit/${wordId}`,
      params: { listId: id },
    });
  };
  
  const handleDeleteWord = (wordId: string) => {
    Alert.alert(
      'Delete Word',
      'Are you sure you want to delete this word?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => deleteWord(id, wordId),
          style: 'destructive',
        },
      ]
    );
  };
  
  const handleStartLearning = () => {
    router.push(`/learning/${id}`);
  };
  
  const handleStartQuiz = () => {
    router.push(`/quiz/${id}`);
  };
  
  const handleEditList = () => {
    router.push(`/list/edit/${id}`);
    setShowOptions(false);
  };
  
  const handleDeleteList = () => {
    Alert.alert(
      'Delete List',
      'Are you sure you want to delete this list? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => {
            deleteList(id);
            router.back();
          },
          style: 'destructive',
        },
      ]
    );
    setShowOptions(false);
  };
  
  const toggleOptions = () => {
    setShowOptions(!showOptions);
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: list.name,
          headerRight: () => (
            <View style={styles.headerRight}>
              <TouchableOpacity 
                onPress={toggleOptions}
                style={styles.headerButton}
              >
                <MoreVertical size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
          ),
        }} 
      />
      
      {showOptions && (
        <View style={styles.optionsMenu}>
          <TouchableOpacity 
            style={styles.optionItem}
            onPress={handleEditList}
          >
            <Edit size={20} color={colors.text} />
            <Text style={styles.optionText}>Edit List</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.optionItem}
            onPress={handleDeleteList}
          >
            <Trash2 size={20} color={colors.error} />
            <Text style={[styles.optionText, { color: colors.error }]}>
              Delete List
            </Text>
          </TouchableOpacity>
        </View>
      )}
      
      <View style={styles.header}>
        <Card style={styles.infoCard}>
          <Text style={styles.description}>{list.description}</Text>
          
          <View style={styles.infoRow}>
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Languages</Text>
              <Text style={styles.infoValue}>
                {getLanguageFlag(list.language)} → {getLanguageFlag(list.targetLanguage)}
              </Text>
            </View>
            
            <View style={styles.infoItem}>
              <Text style={styles.infoLabel}>Words</Text>
              <Text style={styles.infoValue}>
                {list.totalWords} ({list.masteredWords} mastered)
              </Text>
            </View>
          </View>
          
          <View style={styles.progressContainer}>
            <View 
              style={[
                styles.progressBar, 
                { 
                  width: `${list.totalWords > 0 
                    ? Math.round((list.masteredWords / list.totalWords) * 100) 
                    : 0}%` 
                }
              ]} 
            />
          </View>
        </Card>
        
        <View style={styles.actions}>
          <Button
            title="Learn"
            onPress={handleStartLearning}
            leftIcon={<Brain size={18} color="white" />}
            style={styles.actionButton}
          />
          
          <Button
            title="Quiz"
            onPress={handleStartQuiz}
            variant="secondary"
            leftIcon={<Play size={18} color={colors.text} />}
            style={styles.actionButton}
          />
        </View>
      </View>
      
      <View style={styles.wordsHeader}>
        <Text style={styles.wordsTitle}>Words</Text>
        
        <TouchableOpacity 
          style={styles.addButton}
          onPress={handleAddWord}
        >
          <Plus size={20} color="white" />
        </TouchableOpacity>
      </View>
      
      {words.length === 0 ? (
        <EmptyState
          title="No Words Yet"
          description="Add words to this list to start learning"
          icon={<BookOpen size={64} color={colors.textSecondary} />}
          actionLabel="Add Word"
          onAction={handleAddWord}
        />
      ) : (
        <FlatList
          data={words}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <WordCard
              word={item}
              onEdit={() => handleEditWord(item.id)}
              onDelete={() => handleDeleteWord(item.id)}
            />
          )}
          contentContainerStyle={styles.wordsList}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerRight: {
    flexDirection: 'row',
  },
  headerButton: {
    padding: 8,
  },
  optionsMenu: {
    position: 'absolute',
    top: 50,
    right: 16,
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 8,
    zIndex: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    gap: 12,
  },
  optionText: {
    fontSize: 16,
    color: colors.text,
  },
  header: {
    padding: 16,
  },
  infoCard: {
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    color: colors.text,
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  infoItem: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '500',
  },
  progressContainer: {
    height: 6,
    backgroundColor: '#e9ecef',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 3,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
  },
  wordsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  wordsTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
  },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  wordsList: {
    padding: 16,
    paddingTop: 8,
  },
});