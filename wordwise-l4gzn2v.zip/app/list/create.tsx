import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Input } from '@/components/Input';
import { Button } from '@/components/Button';
import { colors } from '@/constants/colors';
import { useWordListsStore } from '@/store/wordListsStore';
import { languages } from '@/mocks/languages';
import { Check } from 'lucide-react-native';

export default function CreateListScreen() {
  const router = useRouter();
  const addList = useWordListsStore(state => state.addList);
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState('en');
  const [targetLanguage, setTargetLanguage] = useState('');
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [showTargetLanguageSelector, setShowTargetLanguageSelector] = useState(false);
  const [selectedColor, setSelectedColor] = useState(colors.primary);
  
  const [errors, setErrors] = useState({
    name: '',
    description: '',
    targetLanguage: '',
  });
  
  const colorOptions = [
    colors.primary,
    colors.secondary,
    colors.accent,
    colors.success,
    colors.warning,
    colors.error,
    '#9c36b5', // Purple
    '#20c997', // Teal
    '#fd7e14', // Orange
  ];
  
  const validateForm = () => {
    const newErrors = {
      name: '',
      description: '',
      targetLanguage: '',
    };
    
    if (!name.trim()) {
      newErrors.name = 'List name is required';
    }
    
    if (!description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    if (!targetLanguage) {
      newErrors.targetLanguage = 'Target language is required';
    }
    
    setErrors(newErrors);
    
    return !newErrors.name && !newErrors.description && !newErrors.targetLanguage;
  };
  
  const handleCreateList = () => {
    if (!validateForm()) return;
    
    addList({
      name,
      description,
      language,
      targetLanguage,
      color: selectedColor,
      tags: [],
    });
    
    router.back();
  };
  
  const toggleLanguageSelector = () => {
    setShowLanguageSelector(!showLanguageSelector);
    if (showTargetLanguageSelector) {
      setShowTargetLanguageSelector(false);
    }
  };
  
  const toggleTargetLanguageSelector = () => {
    setShowTargetLanguageSelector(!showTargetLanguageSelector);
    if (showLanguageSelector) {
      setShowLanguageSelector(false);
    }
  };
  
  const selectLanguage = (code: string) => {
    setLanguage(code);
    setShowLanguageSelector(false);
  };
  
  const selectTargetLanguage = (code: string) => {
    setTargetLanguage(code);
    setShowTargetLanguageSelector(false);
  };
  
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      
      <Stack.Screen 
        options={{
          title: 'Create Word List',
          headerRight: () => (
            <TouchableOpacity 
              onPress={handleCreateList}
              style={styles.headerButton}
            >
              <Text style={styles.headerButtonText}>Create</Text>
            </TouchableOpacity>
          ),
        }} 
      />
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <Input
          label="List Name"
          placeholder="Enter a name for your list"
          value={name}
          onChangeText={setName}
          error={errors.name}
        />
        
        <Input
          label="Description"
          placeholder="Describe what this list is about"
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={3}
          error={errors.description}
        />
        
        <View style={styles.languageSection}>
          <Text style={styles.label}>Your Language</Text>
          
          <TouchableOpacity 
            style={styles.languageSelector}
            onPress={toggleLanguageSelector}
          >
            <View style={styles.selectedLanguage}>
              <Text style={styles.languageFlag}>
                {languages.find(lang => lang.code === language)?.flag || '🌐'}
              </Text>
              <Text style={styles.languageName}>
                {languages.find(lang => lang.code === language)?.name || 'Select Language'}
              </Text>
            </View>
          </TouchableOpacity>
          
          {showLanguageSelector && (
            <View style={styles.languageDropdown}>
              <ScrollView style={styles.languageList}>
                {languages.map(lang => (
                  <TouchableOpacity
                    key={lang.code}
                    style={styles.languageOption}
                    onPress={() => selectLanguage(lang.code)}
                  >
                    <View style={styles.languageOptionContent}>
                      <Text style={styles.languageFlag}>{lang.flag}</Text>
                      <Text style={styles.languageName}>{lang.name}</Text>
                    </View>
                    
                    {language === lang.code && (
                      <Check size={16} color={colors.primary} />
                    )}
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          )}
        </View>
        
        <View style={styles.languageSection}>
          <Text style={styles.label}>Target Language</Text>
          
          <TouchableOpacity 
            style={[
              styles.languageSelector,
              errors.targetLanguage ? styles.errorBorder : null,
            ]}
            onPress={toggleTargetLanguageSelector}
          >
            <View style={styles.selectedLanguage}>
              <Text style={styles.languageFlag}>
                {targetLanguage 
                  ? languages.find(lang => lang.code === targetLanguage)?.flag 
                  : '🌐'}
              </Text>
              <Text style={[
                styles.languageName,
                !targetLanguage ? styles.placeholderText : null,
              ]}>
                {targetLanguage 
                  ? languages.find(lang => lang.code === targetLanguage)?.name 
                  : 'Select Target Language'}
              </Text>
            </View>
          </TouchableOpacity>
          
          {errors.targetLanguage ? (
            <Text style={styles.errorText}>{errors.targetLanguage}</Text>
          ) : null}
          
          {showTargetLanguageSelector && (
            <View style={styles.languageDropdown}>
              <ScrollView style={styles.languageList}>
                {languages
                  .filter(lang => lang.code !== language)
                  .map(lang => (
                    <TouchableOpacity
                      key={lang.code}
                      style={styles.languageOption}
                      onPress={() => selectTargetLanguage(lang.code)}
                    >
                      <View style={styles.languageOptionContent}>
                        <Text style={styles.languageFlag}>{lang.flag}</Text>
                        <Text style={styles.languageName}>{lang.name}</Text>
                      </View>
                      
                      {targetLanguage === lang.code && (
                        <Check size={16} color={colors.primary} />
                      )}
                    </TouchableOpacity>
                  ))}
              </ScrollView>
            </View>
          )}
        </View>
        
        <View style={styles.colorSection}>
          <Text style={styles.label}>List Color</Text>
          
          <View style={styles.colorOptions}>
            {colorOptions.map(color => (
              <TouchableOpacity
                key={color}
                style={[
                  styles.colorOption,
                  { backgroundColor: color },
                  selectedColor === color ? styles.selectedColorOption : null,
                ]}
                onPress={() => setSelectedColor(color)}
              />
            ))}
          </View>
        </View>
        
        <Button
          title="Create List"
          onPress={handleCreateList}
          style={styles.createButton}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  headerButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  headerButtonText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
  },
  languageSection: {
    marginBottom: 16,
    position: 'relative',
    zIndex: 1,
  },
  languageSelector: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    backgroundColor: 'white',
  },
  errorBorder: {
    borderColor: colors.error,
  },
  selectedLanguage: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  languageFlag: {
    fontSize: 18,
    marginRight: 8,
  },
  languageName: {
    fontSize: 16,
    color: colors.text,
  },
  placeholderText: {
    color: colors.textSecondary,
  },
  languageDropdown: {
    position: 'absolute',
    top: 76,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    maxHeight: 200,
    zIndex: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  languageList: {
    flex: 1,
  },
  languageOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  languageOptionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  errorText: {
    color: colors.error,
    fontSize: 14,
    marginTop: 4,
  },
  colorSection: {
    marginBottom: 24,
  },
  colorOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  colorOption: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  selectedColorOption: {
    borderWidth: 2,
    borderColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  createButton: {
    marginBottom: 24,
  },
});