import { QuizResult } from '@/types';

export const mockQuizResults: QuizResult[] = [
  {
    id: '1',
    listId: '1',
    date: '2023-06-15T10:30:00Z',
    totalQuestions: 10,
    correctAnswers: 8,
    timeSpent: 120, // 2 minutes
    words: [
      { wordId: '101', correct: true },
      { wordId: '102', correct: true },
      { wordId: '103', correct: false },
      { wordId: '104', correct: true },
      { wordId: '105', correct: true },
      { wordId: '106', correct: true },
      { wordId: '107', correct: false },
      { wordId: '108', correct: true },
      { wordId: '109', correct: true },
      { wordId: '110', correct: true },
    ],
  },
  {
    id: '2',
    listId: '1',
    date: '2023-06-17T14:45:00Z',
    totalQuestions: 10,
    correctAnswers: 9,
    timeSpent: 115, // 1 minute 55 seconds
    words: [
      { wordId: '101', correct: true },
      { wordId: '102', correct: true },
      { wordId: '103', correct: true },
      { wordId: '104', correct: true },
      { wordId: '105', correct: true },
      { wordId: '106', correct: true },
      { wordId: '107', correct: false },
      { wordId: '108', correct: true },
      { wordId: '109', correct: true },
      { wordId: '110', correct: true },
    ],
  },
  {
    id: '3',
    listId: '2',
    date: '2023-06-16T09:15:00Z',
    totalQuestions: 5,
    correctAnswers: 4,
    timeSpent: 60, // 1 minute
    words: [
      { wordId: '201', correct: true },
      { wordId: '202', correct: true },
      { wordId: '203', correct: true },
      { wordId: '204', correct: false },
      { wordId: '205', correct: true },
    ],
  },
  {
    id: '4',
    listId: '3',
    date: '2023-06-14T16:30:00Z',
    totalQuestions: 3,
    correctAnswers: 2,
    timeSpent: 45, // 45 seconds
    words: [
      { wordId: '301', correct: true },
      { wordId: '302', correct: false },
      { wordId: '303', correct: true },
    ],
  },
];