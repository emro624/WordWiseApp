import { User } from '@/types';

export const mockUser: User = {
  id: 'user1',
  name: 'John Doe',
  email: 'demo@example.com',
  avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  preferences: {
    darkMode: false,
    notifications: true,
    dailyGoal: 20,
    reminderTime: '19:00',
    primaryLanguage: 'en',
  },
  createdAt: '2023-01-15T08:30:00.000Z',
};