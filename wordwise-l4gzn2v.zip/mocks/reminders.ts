import { Reminder } from '@/types';

export const reminders: Reminder[] = [
  {
    id: '1',
    title: 'Daily Practice',
    message: 'Time to practice your Spanish vocabulary!',
    time: '09:00',
    days: [1, 2, 3, 4, 5], // Monday to Friday
    enabled: true,
    type: 'daily',
    createdAt: '2023-05-15T10:30:00Z',
    lastTriggered: '2023-05-22T09:00:00Z',
    nextTrigger: null,
  },
  {
    id: '2',
    title: 'French Review',
    message: 'Review your French vocabulary from last week',
    time: '18:30',
    days: [2, 4], // Tuesday and Thursday
    enabled: true,
    type: 'custom',
    listId: '2', // French vocabulary list
    createdAt: '2023-06-01T15:45:00Z',
    lastTriggered: '2023-06-06T18:30:00Z',
    nextTrigger: null,
  },
  {
    id: '3',
    title: 'Smart Learning',
    message: 'Time to practice words you might be forgetting',
    time: '20:00',
    days: [0, 1, 2, 3, 4, 5, 6], // Every day
    enabled: true,
    type: 'smart',
    listId: '1', // Spanish vocabulary list
    dailyGoal: 15,
    createdAt: '2023-06-10T09:15:00Z',
    lastTriggered: '2023-06-15T20:00:00Z',
    nextTrigger: '2023-06-18T20:00:00Z',
  }
];