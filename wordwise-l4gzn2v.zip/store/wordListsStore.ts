import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WordList, Word, QuizResult } from '@/types';
import { mockWordLists } from '@/mocks/wordLists';
import { mockWords } from '@/mocks/words';
import { mockQuizResults } from '@/mocks/quizResults';

interface WordListsState {
  lists: WordList[];
  words: Record<string, Word[]>;
  quizResults: QuizResult[];
  isLoading: boolean;
  error: string | null;
  
  // List operations
  getLists: () => WordList[];
  getList: (id: string) => WordList | undefined;
  addList: (list: Omit<WordList, 'id' | 'createdAt' | 'updatedAt' | 'totalWords' | 'masteredWords'>) => void;
  updateList: (id: string, data: Partial<WordList>) => void;
  deleteList: (id: string) => void;
  
  // Word operations
  getWords: (listId: string) => Word[];
  getAllWords: () => Word[];
  getWord: (listId: string, wordId: string) => Word | undefined;
  addWord: (word: Omit<Word, 'id' | 'createdAt' | 'progress'>) => void;
  updateWord: (listId: string, wordId: string, data: Partial<Word>) => void;
  deleteWord: (listId: string, wordId: string) => void;
  updateWordProgress: (listId: string, wordId: string, correct: boolean) => void;
  
  // Quiz operations
  getQuizResults: (listId: string) => QuizResult[];
  addQuizResult: (result: Omit<QuizResult, 'id' | 'date'>) => void;
  
  // Stats
  getListProgress: (listId: string) => { total: number; mastered: number; percentage: number };
  getOverallProgress: () => { total: number; mastered: number; percentage: number };
  getStreak: () => number;
  getRecentActivity: () => { date: string; count: number }[];
}

export const useWordListsStore = create<WordListsState>()(
  persist(
    (set, get) => ({
      lists: mockWordLists,
      words: mockWords,
      quizResults: mockQuizResults,
      isLoading: false,
      error: null,
      
      // List operations
      getLists: () => get().lists,
      
      getList: (id) => get().lists.find(list => list.id === id),
      
      addList: (list) => {
        const newList: WordList = {
          ...list,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          totalWords: 0,
          masteredWords: 0,
        };
        
        set((state) => ({
          lists: [...state.lists, newList],
          words: { ...state.words, [newList.id]: [] },
        }));
      },
      
      updateList: (id, data) => {
        set((state) => ({
          lists: state.lists.map(list => 
            list.id === id 
              ? { 
                  ...list, 
                  ...data, 
                  updatedAt: new Date().toISOString() 
                } 
              : list
          ),
        }));
      },
      
      deleteList: (id) => {
        set((state) => ({
          lists: state.lists.filter(list => list.id !== id),
          words: Object.fromEntries(
            Object.entries(state.words).filter(([listId]) => listId !== id)
          ),
          quizResults: state.quizResults.filter(result => result.listId !== id),
        }));
      },
      
      // Word operations
      getWords: (listId) => get().words[listId] || [],
      
      // Function to get all words from all lists
      getAllWords: () => {
        const allWords: Word[] = [];
        const wordsObj = get().words;
        
        Object.keys(wordsObj).forEach(listId => {
          if (wordsObj[listId]) {
            allWords.push(...wordsObj[listId]);
          }
        });
        
        return allWords;
      },
      
      getWord: (listId, wordId) => {
        const listWords = get().words[listId] || [];
        return listWords.find(word => word.id === wordId);
      },
      
      addWord: (word) => {
        const newWord: Word = {
          ...word,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
          progress: {
            status: 'new',
            correctCount: 0,
            incorrectCount: 0,
            strength: 0,
          },
        };
        
        set((state) => {
          const listWords = state.words[newWord.listId] || [];
          const updatedWords = { 
            ...state.words, 
            [newWord.listId]: [...listWords, newWord] 
          };
          
          // Update list stats
          const list = state.lists.find(l => l.id === newWord.listId);
          if (list) {
            const updatedList = { 
              ...list, 
              totalWords: list.totalWords + 1,
              updatedAt: new Date().toISOString(),
            };
            
            return {
              words: updatedWords,
              lists: state.lists.map(l => l.id === newWord.listId ? updatedList : l),
            };
          }
          
          return { words: updatedWords };
        });
      },
      
      updateWord: (listId, wordId, data) => {
        set((state) => {
          const listWords = state.words[listId] || [];
          const updatedWords = {
            ...state.words,
            [listId]: listWords.map(word => 
              word.id === wordId ? { ...word, ...data } : word
            ),
          };
          
          return { words: updatedWords };
        });
      },
      
      deleteWord: (listId, wordId) => {
        set((state) => {
          const listWords = state.words[listId] || [];
          const wordToDelete = listWords.find(w => w.id === wordId);
          const updatedWords = {
            ...state.words,
            [listId]: listWords.filter(word => word.id !== wordId),
          };
          
          // Update list stats
          const list = state.lists.find(l => l.id === listId);
          if (list && wordToDelete) {
            const isMastered = wordToDelete.progress.status === 'mastered';
            const updatedList = { 
              ...list, 
              totalWords: Math.max(0, list.totalWords - 1),
              masteredWords: isMastered ? Math.max(0, list.masteredWords - 1) : list.masteredWords,
              updatedAt: new Date().toISOString(),
            };
            
            return {
              words: updatedWords,
              lists: state.lists.map(l => l.id === listId ? updatedList : l),
            };
          }
          
          return { words: updatedWords };
        });
      },
      
      updateWordProgress: (listId, wordId, correct) => {
        set((state) => {
          const listWords = state.words[listId] || [];
          const wordIndex = listWords.findIndex(w => w.id === wordId);
          
          if (wordIndex === -1) return state;
          
          const word = listWords[wordIndex];
          const oldStatus = word.progress.status;
          
          // Update progress
          const newCorrectCount = word.progress.correctCount + (correct ? 1 : 0);
          const newIncorrectCount = word.progress.incorrectCount + (correct ? 0 : 1);
          const totalAttempts = newCorrectCount + newIncorrectCount;
          
          // Calculate new strength (0-100)
          const newStrength = Math.min(
            100, 
            Math.round((newCorrectCount / Math.max(1, totalAttempts)) * 100)
          );
          
          // Determine new status
          let newStatus = word.progress.status;
          if (newStrength >= 90 && totalAttempts >= 5) {
            newStatus = 'mastered';
          } else if (newStrength >= 70) {
            newStatus = 'reviewing';
          } else if (newStrength >= 30) {
            newStatus = 'learning';
          } else {
            newStatus = 'new';
          }
          
          // Calculate next review date based on spaced repetition
          const now = new Date();
          let daysToAdd = 1;
          
          if (newStatus === 'mastered') {
            daysToAdd = 7; // Review mastered words weekly
          } else if (newStatus === 'reviewing') {
            daysToAdd = 3; // Review every 3 days
          } else if (newStatus === 'learning') {
            daysToAdd = 1; // Review daily
          } else {
            daysToAdd = 1; // New words daily
          }
          
          const nextReviewDate = new Date(now);
          nextReviewDate.setDate(now.getDate() + daysToAdd);
          
          const updatedWord = {
            ...word,
            progress: {
              ...word.progress,
              status: newStatus,
              correctCount: newCorrectCount,
              incorrectCount: newIncorrectCount,
              lastReviewed: now.toISOString(),
              nextReviewDate: nextReviewDate.toISOString(),
              strength: newStrength,
            },
          };
          
          const updatedWords = {
            ...state.words,
            [listId]: [
              ...listWords.slice(0, wordIndex),
              updatedWord,
              ...listWords.slice(wordIndex + 1),
            ],
          };
          
          // Update list stats if status changed to/from mastered
          const list = state.lists.find(l => l.id === listId);
          if (list && oldStatus !== newStatus) {
            let masteredDelta = 0;
            
            if (oldStatus !== 'mastered' && newStatus === 'mastered') {
              masteredDelta = 1;
            } else if (oldStatus === 'mastered' && newStatus !== 'mastered') {
              masteredDelta = -1;
            }
            
            if (masteredDelta !== 0) {
              const updatedList = {
                ...list,
                masteredWords: Math.max(0, list.masteredWords + masteredDelta),
                updatedAt: new Date().toISOString(),
              };
              
              return {
                words: updatedWords,
                lists: state.lists.map(l => l.id === listId ? updatedList : l),
              };
            }
          }
          
          return { words: updatedWords };
        });
      },
      
      // Quiz operations
      getQuizResults: (listId) => {
        return get().quizResults.filter(result => result.listId === listId);
      },
      
      addQuizResult: (result) => {
        const newResult: QuizResult = {
          ...result,
          id: Date.now().toString(),
          date: new Date().toISOString(),
        };
        
        set((state) => ({
          quizResults: [...state.quizResults, newResult],
        }));
        
        // Update word progress for each word in the quiz
        if (result.words) {
          result.words.forEach(({ wordId, correct }) => {
            get().updateWordProgress(result.listId, wordId, correct);
          });
        }
      },
      
      // Stats
      getListProgress: (listId) => {
        const list = get().getList(listId);
        if (!list) return { total: 0, mastered: 0, percentage: 0 };
        
        return {
          total: list.totalWords,
          mastered: list.masteredWords,
          percentage: list.totalWords > 0 
            ? Math.round((list.masteredWords / list.totalWords) * 100) 
            : 0,
        };
      },
      
      getOverallProgress: () => {
        const lists = get().lists;
        const totalWords = lists.reduce((sum, list) => sum + list.totalWords, 0);
        const masteredWords = lists.reduce((sum, list) => sum + list.masteredWords, 0);
        
        return {
          total: totalWords,
          mastered: masteredWords,
          percentage: totalWords > 0 ? Math.round((masteredWords / totalWords) * 100) : 0,
        };
      },
      
      getStreak: () => {
        // Simplified streak calculation for demo
        // In a real app, this would track daily usage
        return 7; // Mock 7-day streak
      },
      
      getRecentActivity: () => {
        // Generate mock activity data for the last 7 days
        const result = [];
        const now = new Date();
        
        for (let i = 6; i >= 0; i--) {
          const date = new Date(now);
          date.setDate(now.getDate() - i);
          const dateStr = date.toISOString().split('T')[0];
          
          // Random activity count between 0 and 30
          const count = Math.floor(Math.random() * 31);
          
          result.push({ date: dateStr, count });
        }
        
        return result;
      },
    }),
    {
      name: 'wordwise-lists-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        lists: state.lists,
        words: state.words,
        quizResults: state.quizResults,
      }),
    }
  )
);