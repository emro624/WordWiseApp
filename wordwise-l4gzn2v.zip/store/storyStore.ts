import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Story } from '@/types';
import { stories as mockStories } from '@/mocks/stories';

interface StoryState {
  stories: Story[];
  readStories: string[]; // IDs of read stories
  bookmarkedStories: string[]; // IDs of bookmarked stories
  downloadedStories: string[]; // IDs of downloaded stories
  isLoading: boolean;
  
  // Getters
  getStories: () => Story[];
  getStory: (id: string) => Story | undefined;
  getBookmarkedStories: () => Story[];
  getDownloadedStories: () => Story[];
  isStoryRead: (id: string) => boolean;
  isStoryBookmarked: (id: string) => boolean;
  isStoryDownloaded: (id: string) => boolean;
  
  // Actions
  markStoryAsRead: (id: string) => void;
  bookmarkStory: (id: string) => void;
  downloadStory: (id: string) => void;
  removeDownload: (id: string) => void;
  
  // Story recommendations
  getRecommendedStories: (language: string, level: string) => Story[];
}

export const useStoryStore = create<StoryState>()(
  persist(
    (set, get) => ({
      stories: mockStories,
      readStories: [],
      bookmarkedStories: [],
      downloadedStories: [],
      isLoading: false,
      
      getStories: () => get().stories,
      
      getStory: (id: string) => {
        return get().stories.find(story => story.id === id);
      },
      
      getBookmarkedStories: () => {
        const { stories, bookmarkedStories } = get();
        return stories.filter(story => bookmarkedStories.includes(story.id));
      },
      
      getDownloadedStories: () => {
        const { stories, downloadedStories } = get();
        return stories.filter(story => downloadedStories.includes(story.id));
      },
      
      isStoryRead: (id: string) => {
        return get().readStories.includes(id);
      },
      
      isStoryBookmarked: (id: string) => {
        return get().bookmarkedStories.includes(id);
      },
      
      isStoryDownloaded: (id: string) => {
        return get().downloadedStories.includes(id);
      },
      
      markStoryAsRead: (id: string) => {
        const { readStories } = get();
        if (!readStories.includes(id)) {
          set({ readStories: [...readStories, id] });
        }
      },
      
      bookmarkStory: (id: string) => {
        const { bookmarkedStories } = get();
        if (bookmarkedStories.includes(id)) {
          // Remove bookmark
          set({ 
            bookmarkedStories: bookmarkedStories.filter(storyId => storyId !== id) 
          });
        } else {
          // Add bookmark
          set({ bookmarkedStories: [...bookmarkedStories, id] });
        }
      },
      
      downloadStory: (id: string) => {
        const { downloadedStories } = get();
        if (!downloadedStories.includes(id)) {
          // Simulate download delay
          set({ isLoading: true });
          
          setTimeout(() => {
            set({ 
              downloadedStories: [...downloadedStories, id],
              isLoading: false
            });
          }, 1500);
        }
      },
      
      removeDownload: (id: string) => {
        const { downloadedStories } = get();
        set({ 
          downloadedStories: downloadedStories.filter(storyId => storyId !== id) 
        });
      },
      
      getRecommendedStories: (language: string, level: string) => {
        const { stories, readStories } = get();
        
        // Filter stories by language and level, excluding already read stories
        return stories.filter(story => 
          story.language === language && 
          story.level === level && 
          !readStories.includes(story.id)
        ).slice(0, 3); // Return top 3 recommendations
      },
    }),
    {
      name: 'story-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);