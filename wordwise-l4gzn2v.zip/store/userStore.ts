import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User, UserPreferences } from '@/types';

interface UserState {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => Promise<void>;
  register: (user: User) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (userData: Partial<User>) => Promise<void>;
  updatePreferences: (preferences: Partial<UserPreferences>) => Promise<void>;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      
      login: async (user: User) => {
        set({ user, isAuthenticated: true });
      },
      
      register: async (user: User) => {
        set({ user, isAuthenticated: true });
      },
      
      logout: async () => {
        set({ user: null, isAuthenticated: false });
      },
      
      updateUser: async (userData: Partial<User>) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null,
        }));
      },
      
      updatePreferences: async (preferences: Partial<UserPreferences>) => {
        set((state) => ({
          user: state.user 
            ? { 
                ...state.user, 
                preferences: { 
                  ...state.user.preferences, 
                  ...preferences 
                } 
              } 
            : null,
        }));
      },
    }),
    {
      name: 'user-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);