import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Reminder } from '@/types';
import { reminders as mockReminders } from '@/mocks/reminders';

// Add declaration for uuid module
declare module 'uuid' {
  export function v4(): string;
}

import { v4 as uuidv4 } from 'uuid';

interface ReminderState {
  reminders: Reminder[];
  
  // Getters
  getReminders: () => Reminder[];
  getReminder: (id: string) => Reminder | undefined;
  getDueReminders: () => Reminder[];
  
  // Actions
  addReminder: (data: Omit<Reminder, 'id' | 'createdAt' | 'lastTriggered' | 'nextTrigger'>) => void;
  updateReminder: (id: string, data: Partial<Omit<Reminder, 'id' | 'createdAt'>>) => void;
  deleteReminder: (id: string) => void;
  toggleReminder: (id: string) => void;
  markReminderTriggered: (id: string) => void;
  
  // Smart reminder functions
  calculateNextTrigger: (reminder: Reminder) => string;
  getSpacedRepetitionInterval: (wordStrength: number) => number;
}

export const useReminderStore = create<ReminderState>()(
  persist(
    (set, get) => ({
      reminders: mockReminders,
      
      getReminders: () => get().reminders,
      
      getReminder: (id: string) => {
        return get().reminders.find(reminder => reminder.id === id);
      },
      
      getDueReminders: () => {
        const now = new Date();
        return get().reminders.filter(reminder => {
          if (!reminder.enabled) return false;
          
          // Check if today is one of the scheduled days
          const today = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
          if (!reminder.days.includes(today)) return false;
          
          // For smart reminders, check if it's due based on nextTrigger
          if (reminder.type === 'smart' && reminder.nextTrigger) {
            const nextTrigger = new Date(reminder.nextTrigger);
            return nextTrigger <= now;
          }
          
          // For daily and custom reminders, check if current time is past the scheduled time
          const [hours, minutes] = reminder.time.split(':').map(Number);
          const scheduledTime = new Date(now);
          scheduledTime.setHours(hours, minutes, 0, 0);
          
          return now >= scheduledTime;
        });
      },
      
      addReminder: (data) => {
        const now = new Date();
        const newReminder: Reminder = {
          id: uuidv4(),
          ...data,
          createdAt: now.toISOString(),
          lastTriggered: null,
          nextTrigger: null,
        };
        
        // Calculate next trigger time for smart reminders
        if (newReminder.type === 'smart') {
          newReminder.nextTrigger = get().calculateNextTrigger(newReminder);
        }
        
        set({ reminders: [...get().reminders, newReminder] });
      },
      
      updateReminder: (id, data) => {
        const { reminders } = get();
        const updatedReminders = reminders.map(reminder => {
          if (reminder.id === id) {
            const updatedReminder = { ...reminder, ...data };
            
            // Recalculate next trigger time for smart reminders if relevant fields changed
            if (
              updatedReminder.type === 'smart' && 
              (data.type !== undefined || data.time !== undefined || data.days !== undefined)
            ) {
              updatedReminder.nextTrigger = get().calculateNextTrigger(updatedReminder);
            }
            
            return updatedReminder;
          }
          return reminder;
        });
        
        set({ reminders: updatedReminders });
      },
      
      deleteReminder: (id) => {
        const { reminders } = get();
        const updatedReminders = reminders.filter(reminder => reminder.id !== id);
        
        set({ reminders: updatedReminders });
      },
      
      toggleReminder: (id) => {
        const { reminders } = get();
        const updatedReminders = reminders.map(reminder => 
          reminder.id === id ? { ...reminder, enabled: !reminder.enabled } : reminder
        );
        
        set({ reminders: updatedReminders });
      },
      
      markReminderTriggered: (id) => {
        const { reminders } = get();
        const now = new Date();
        
        const updatedReminders = reminders.map(reminder => {
          if (reminder.id === id) {
            const updatedReminder = { 
              ...reminder, 
              lastTriggered: now.toISOString() 
            };
            
            // Calculate next trigger time for smart reminders
            if (updatedReminder.type === 'smart') {
              updatedReminder.nextTrigger = get().calculateNextTrigger(updatedReminder);
            }
            
            return updatedReminder;
          }
          return reminder;
        });
        
        set({ reminders: updatedReminders });
      },
      
      calculateNextTrigger: (reminder) => {
        const now = new Date();
        
        // For non-smart reminders, just use the next occurrence of the scheduled time
        if (reminder.type !== 'smart') {
          const [hours, minutes] = reminder.time.split(':').map(Number);
          const nextTrigger = new Date(now);
          nextTrigger.setHours(hours, minutes, 0, 0);
          
          // If the time has already passed today, set it for tomorrow
          if (nextTrigger <= now) {
            nextTrigger.setDate(nextTrigger.getDate() + 1);
          }
          
          // Find the next day that matches the reminder's schedule
          let daysToAdd = 0;
          while (!reminder.days.includes((nextTrigger.getDay() + daysToAdd) % 7)) {
            daysToAdd++;
          }
          
          if (daysToAdd > 0) {
            nextTrigger.setDate(nextTrigger.getDate() + daysToAdd);
          }
          
          return nextTrigger.toISOString();
        }
        
        // For smart reminders, use spaced repetition algorithm
        // This is a simplified version - in a real app, this would be more sophisticated
        // and would take into account the user's actual learning progress
        
        // Simulate word strength (0-100) - in a real app, this would come from the user's learning data
        const wordStrength = reminder.lastTriggered 
          ? Math.min(100, Math.floor(Math.random() * 100)) // Simulate progress for existing reminders
          : 0; // New words start at 0
        
        // Get interval based on word strength
        const daysInterval = get().getSpacedRepetitionInterval(wordStrength);
        
        // Calculate next trigger date
        const nextTrigger = new Date(now);
        nextTrigger.setDate(nextTrigger.getDate() + daysInterval);
        
        // Set the time component
        const [hours, minutes] = reminder.time.split(':').map(Number);
        nextTrigger.setHours(hours, minutes, 0, 0);
        
        // Ensure the next trigger falls on one of the selected days
        while (!reminder.days.includes(nextTrigger.getDay())) {
          nextTrigger.setDate(nextTrigger.getDate() + 1);
        }
        
        return nextTrigger.toISOString();
      },
      
      getSpacedRepetitionInterval: (wordStrength: number) => {
        // Implement a spaced repetition algorithm
        // This is a simplified version of the SuperMemo-2 algorithm
        
        if (wordStrength < 25) {
          return 1; // Review daily for new or difficult words
        } else if (wordStrength < 50) {
          return 3; // Review every 3 days for words being learned
        } else if (wordStrength < 75) {
          return 7; // Review weekly for words being mastered
        } else {
          return 14; // Review every two weeks for well-known words
        }
      },
    }),
    {
      name: 'reminder-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);