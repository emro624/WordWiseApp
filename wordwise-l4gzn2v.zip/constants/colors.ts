export const colors = {
  primary: '#5D69E3', // Main brand color - a vibrant indigo
  secondary: '#F0F2FF', // Light indigo for secondary elements
  success: '#4CAF50', // Green for success states
  warning: '#FFC107', // Amber for warnings
  error: '#F44336', // Red for errors
  
  // Text colors
  text: '#2D3748', // Dark gray for primary text
  textSecondary: '#718096', // Medium gray for secondary text
  
  // Background colors
  background: '#F8FAFC', // Very light gray for app background
  card: '#FFFFFF', // White for card backgrounds
  inputBackground: '#FFFFFF', // White for input backgrounds
  
  // Border colors
  border: '#E2E8F0', // Light gray for borders
  
  // Status colors
  new: '#CBD5E0', // Gray for new items
  learning: '#FFC107', // Amber for learning items
  reviewing: '#4299E1', // Blue for reviewing items
  mastered: '#48BB78', // Green for mastered items
};